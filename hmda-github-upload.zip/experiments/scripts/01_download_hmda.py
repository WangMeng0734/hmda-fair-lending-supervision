from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import time
import urllib.parse
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
CONFIG_PATH = PROJECT_ROOT / "experiments" / "config" / "project.json"


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def download(year: int, state: str, overwrite: bool = False, max_attempts: int = 12) -> Path:
    state = state.upper()
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    params = urllib.parse.urlencode({"states": state, "years": year})
    url = f"{config['api_base']}?{params}"

    output_dir = PROJECT_ROOT / "data" / "data" / "raw" / "hmda" / f"year={year}"
    output_dir.mkdir(parents=True, exist_ok=True)
    csv_path = output_dir / f"hmda_{state}_{year}.csv"
    partial_path = csv_path.with_suffix(".csv.part")
    metadata_path = csv_path.with_suffix(".metadata.json")

    if csv_path.exists() and not overwrite:
        print(f"SKIP existing file: {csv_path}")
        return csv_path

    command = [
            "curl.exe",
            "-L",
            "--fail",
            "--retry-all-errors",
            "--retry-connrefused",
            "--retry",
            "10",
            "--retry-delay",
            "5",
            "--connect-timeout",
            "30",
            "--max-time",
            "7200",
        ]

    # The CFPB endpoint occasionally closes large transfers early.  Each outer
    # attempt resumes the same .part file, so a transient disconnect does not
    # discard hundreds of megabytes already received.
    last_error = ""
    for attempt in range(1, max_attempts + 1):
        attempt_command = list(command)
        if partial_path.exists() and partial_path.stat().st_size > 0:
            attempt_command.extend(["-C", "-"])
        attempt_command.extend(["--output", str(partial_path), url])
        print(
            f"DOWNLOAD attempt={attempt}/{max_attempts} state={state} year={year} "
            f"resume_bytes={partial_path.stat().st_size if partial_path.exists() else 0}",
            flush=True,
        )
        proc = subprocess.run(attempt_command, text=True, capture_output=True)
        if proc.returncode == 0:
            break
        last_error = (proc.stderr or proc.stdout or f"curl exit {proc.returncode}")[-4000:]
        print(f"RETRY curl_exit={proc.returncode}: {last_error}", file=sys.stderr, flush=True)
        if attempt < max_attempts:
            time.sleep(min(60, 5 * attempt))
    else:
        raise RuntimeError(
            f"Download failed after {max_attempts} resumable attempts for {state} {year}: {last_error}"
        )

    if not partial_path.exists() or partial_path.stat().st_size == 0:
        raise RuntimeError(f"Download returned an empty file for {state} {year}")

    partial_path.replace(csv_path)
    metadata = {
        "source_url": url,
        "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
        "year": year,
        "state": state,
        "bytes": csv_path.stat().st_size,
        "sha256": sha256_file(csv_path),
    }
    metadata_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(metadata, ensure_ascii=False, indent=2))
    return csv_path


def main() -> None:
    parser = argparse.ArgumentParser(description="Download an official filtered HMDA CSV.")
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--state", required=True, help="Two-letter state code, for example DC or CA")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--max-attempts", type=int, default=12)
    args = parser.parse_args()
    if len(args.state) != 2:
        sys.exit("--state must be a two-letter code")
    download(args.year, args.state, args.overwrite, args.max_attempts)


if __name__ == "__main__":
    main()
