from __future__ import annotations

import csv
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "experiments" / "vendor"))
import duckdb  # noqa: E402


MODEL_DIR = PROJECT_ROOT / "data" / "data" / "modeling"
REPORT_DIR = PROJECT_ROOT / "results" / "data_quality"
LOG_PATH = PROJECT_ROOT / "experiments" / "logs" / "modeling_tables_build.json"
DB_PATH = PROJECT_ROOT / "data" / "database" / "hmda.duckdb"

PEER_PATH = MODEL_DIR / "main_homogeneous_peer.parquet"
AUDIT_PATH = MODEL_DIR / "main_homogeneous_audit.parquet"
POST_PATH = MODEL_DIR / "main_post_decision_validation.parquet"
ROBUST_PATH = MODEL_DIR / "robustness_binary_audit.parquet"


def q(path: Path) -> str:
    return str(path).replace("'", "''").replace("\\", "/")


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


VARIABLES = [
    ("application_row_id", "identifier", "pre-decision", "Stable state-year-source-row identifier"),
    ("y_denied", "outcome", "decision", "1=denied (action 3 or 7); 0=approved (action 1 or 2)"),
    ("y_action_taken_code", "outcome_source", "decision", "Original action code retained only for outcome-definition sensitivity analyses"),
    ("x_activity_year", "model_feature", "pre-decision", "HMDA activity year"),
    ("x_state_code", "model_feature", "pre-decision", "Two-letter state code"),
    ("x_county_code", "model_feature", "pre-decision", "County FIPS code; broad geography control"),
    ("x_msa_md", "model_feature", "pre-decision", "Derived metropolitan statistical area/division"),
    ("x_preapproval", "model_feature", "pre-decision", "Preapproval program indicator"),
    ("x_loan_type", "model_feature", "pre-decision", "Conventional/FHA/VA/RHS loan type code"),
    ("x_loan_amount", "model_feature", "pre-decision", "Loan amount in HMDA-reported dollars"),
    ("x_ltv", "model_feature", "pre-decision", "Combined loan-to-value ratio"),
    ("x_property_value", "model_feature", "pre-decision", "Property value in HMDA-reported dollars"),
    ("x_income_thousands", "model_feature", "pre-decision", "Applicant income in thousands of dollars"),
    ("x_dti_category", "model_feature", "pre-decision", "Debt-to-income value/band; NA converted to null, Exempt retained"),
    ("x_tract_population", "model_feature", "context", "Census tract population"),
    ("x_ffiec_msa_median_family_income", "model_feature", "context", "FFIEC MSA/MD median family income"),
    ("x_tract_to_msa_income_pct", "model_feature", "context", "Tract income as percent of MSA/MD income"),
    ("x_tract_owner_occupied_units", "model_feature", "context", "Owner-occupied units in tract"),
    ("x_tract_one_to_four_family_homes", "model_feature", "context", "One-to-four-family homes in tract"),
    ("x_tract_median_housing_age", "model_feature", "context", "Median age of tract housing stock"),
    ("x_ltv_missing", "missing_indicator", "pre-decision", "1 when x_ltv is missing"),
    ("x_property_value_missing", "missing_indicator", "pre-decision", "1 when x_property_value is missing"),
    ("x_income_missing", "missing_indicator", "pre-decision", "1 when x_income_thousands is missing"),
    ("x_dti_missing", "missing_indicator", "pre-decision", "1 when DTI is NA/null"),
    ("g_lender_lei", "grouping", "pre-decision", "Lender Legal Entity Identifier; excluded from peer benchmark features"),
    ("a_census_tract", "audit_only", "context", "Census tract; excluded from peer benchmark to reduce proxy absorption"),
    ("a_tract_minority_population_pct", "audit_only", "context", "Tract minority population percentage"),
    ("a_derived_race", "protected_audit", "pre-decision", "HMDA derived applicant/co-applicant race"),
    ("a_derived_ethnicity", "protected_audit", "pre-decision", "HMDA derived ethnicity"),
    ("a_derived_sex", "protected_audit", "pre-decision", "HMDA derived sex"),
    ("a_applicant_age", "protected_audit", "pre-decision", "Applicant age band"),
    ("a_coapplicant_age", "protected_audit", "pre-decision", "Co-applicant age band"),
    ("a_applicant_age_above_62", "protected_audit", "pre-decision", "Applicant age-above-62 indicator"),
    ("a_coapplicant_age_above_62", "protected_audit", "pre-decision", "Co-applicant age-above-62 indicator"),
    ("a_applicant_sex_code", "protected_audit", "pre-decision", "Primary applicant sex code"),
    ("a_applicant_ethnicity_1", "protected_audit", "pre-decision", "Primary applicant ethnicity code"),
    ("a_applicant_race_1", "protected_audit", "pre-decision", "Primary applicant race code"),
    ("s_applicant_credit_score_type", "sensitivity_only", "pre-decision", "Credit score model type, not the credit score value"),
    ("s_coapplicant_credit_score_type", "sensitivity_only", "pre-decision", "Co-applicant credit score model type"),
    ("z_action_taken", "validation_only", "decision", "Original HMDA action code"),
    ("z_denial_reason_1", "post_decision", "post-decision", "First reported denial reason"),
    ("z_denial_reason_2", "post_decision", "post-decision", "Second reported denial reason"),
    ("z_denial_reason_3", "post_decision", "post-decision", "Third reported denial reason"),
    ("z_denial_reason_4", "post_decision", "post-decision", "Fourth reported denial reason"),
    ("z_purchaser_type", "post_decision", "post-decision", "Purchaser type"),
    ("z_interest_rate", "post_decision", "post-decision", "Interest rate"),
    ("z_rate_spread", "post_decision", "post-decision", "Rate spread"),
    ("z_total_loan_costs", "post_decision", "post-decision", "Total loan costs"),
    ("z_origination_charges", "post_decision", "post-decision", "Origination charges"),
    ("x_loan_purpose", "robustness_feature", "pre-decision", "Loan purpose code"),
    ("x_lien_status", "robustness_feature", "pre-decision", "Lien status code"),
    ("x_occupancy_type", "robustness_feature", "pre-decision", "Occupancy type code"),
    ("x_construction_method", "robustness_feature", "pre-decision", "Construction method code"),
    ("x_reverse_mortgage", "robustness_feature", "pre-decision", "Reverse-mortgage code"),
    ("x_open_end_line_of_credit", "robustness_feature", "pre-decision", "Open-end line-of-credit code"),
    ("x_business_or_commercial_purpose", "robustness_feature", "pre-decision", "Business/commercial-purpose code"),
    ("x_total_units", "robustness_feature", "pre-decision", "Total dwelling units"),
    ("x_derived_loan_product_type", "robustness_feature", "pre-decision", "Derived loan product type"),
    ("x_derived_dwelling_category", "robustness_feature", "pre-decision", "Derived dwelling category"),
]


def main() -> None:
    started = time.time()
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    for output in (PEER_PATH, AUDIT_PATH, POST_PATH, ROBUST_PATH):
        if output.exists():
            output.unlink()

    config = json.loads((PROJECT_ROOT / "experiments" / "config" / "project.json").read_text(encoding="utf-8"))
    states = ", ".join(f"'{s}'" for s in config["planned_main_sample"]["states"])
    years = ", ".join(str(y) for y in config["planned_main_sample"]["years"])
    source_glob = q(PROJECT_ROOT / "data" / "data" / "processed" / "hmda" / "state=*" / "year=*" / "data.parquet")
    source = f"read_parquet('{source_glob}', union_by_name=true, filename=true, file_row_number=true)"
    main_scope = f"state_code IN ({states}) AND activity_year IN ({years})"
    binary = "action_taken IN (1, 2, 3, 7)"
    homogeneous = """
        loan_purpose = 1
        AND lien_status = 1
        AND occupancy_type = 1
        AND construction_method = 1
        AND business_or_commercial_purpose = 2
        AND reverse_mortgage = 2
        AND open_end_line_of_credit = 2
        AND total_units = '1'
    """

    shared_columns = """
        concat(state_code, '-', cast(activity_year AS VARCHAR), '-',
               lpad(cast(file_row_number AS VARCHAR), 10, '0')) AS application_row_id,
        cast(denied AS TINYINT) AS y_denied,
        action_taken AS y_action_taken_code,
        activity_year AS x_activity_year,
        state_code AS x_state_code,
        county_code AS x_county_code,
        derived_msa_md AS x_msa_md,
        preapproval AS x_preapproval,
        loan_type AS x_loan_type,
        loan_amount AS x_loan_amount,
        loan_to_value_ratio AS x_ltv,
        property_value AS x_property_value,
        income_thousands AS x_income_thousands,
        nullif(debt_to_income_ratio, 'NA') AS x_dti_category,
        tract_population AS x_tract_population,
        ffiec_msa_md_median_family_income AS x_ffiec_msa_median_family_income,
        tract_to_msa_income_percentage AS x_tract_to_msa_income_pct,
        tract_owner_occupied_units AS x_tract_owner_occupied_units,
        tract_one_to_four_family_homes AS x_tract_one_to_four_family_homes,
        tract_median_age_of_housing_units AS x_tract_median_housing_age,
        cast(loan_to_value_ratio IS NULL AS TINYINT) AS x_ltv_missing,
        cast(property_value IS NULL AS TINYINT) AS x_property_value_missing,
        cast(income_thousands IS NULL AS TINYINT) AS x_income_missing,
        cast(debt_to_income_ratio IS NULL OR debt_to_income_ratio = 'NA' AS TINYINT) AS x_dti_missing
    """
    audit_columns = """
        lei AS g_lender_lei,
        census_tract AS a_census_tract,
        tract_minority_population_percent AS a_tract_minority_population_pct,
        derived_race AS a_derived_race,
        derived_ethnicity AS a_derived_ethnicity,
        derived_sex AS a_derived_sex,
        applicant_age AS a_applicant_age,
        co_applicant_age AS a_coapplicant_age,
        applicant_age_above_62 AS a_applicant_age_above_62,
        co_applicant_age_above_62 AS a_coapplicant_age_above_62,
        applicant_sex_code AS a_applicant_sex_code,
        applicant_ethnicity_1 AS a_applicant_ethnicity_1,
        applicant_race_1 AS a_applicant_race_1,
        applicant_credit_score_type AS s_applicant_credit_score_type,
        co_applicant_credit_score_type AS s_coapplicant_credit_score_type
    """

    con = duckdb.connect(str(DB_PATH))
    con.execute("PRAGMA threads=8")
    con.execute("PRAGMA preserve_insertion_order=false")

    print("[1/8] Writing leakage-safe peer benchmark table", flush=True)
    con.execute(
        f"""
        COPY (
            SELECT {shared_columns}
            FROM {source}
            WHERE {main_scope} AND {binary} AND {homogeneous}
        ) TO '{q(PEER_PATH)}' (FORMAT PARQUET, COMPRESSION ZSTD)
        """
    )

    print("[2/8] Writing institution audit table", flush=True)
    con.execute(
        f"""
        COPY (
            SELECT {shared_columns}, {audit_columns}
            FROM {source}
            WHERE {main_scope} AND {binary} AND {homogeneous}
        ) TO '{q(AUDIT_PATH)}' (FORMAT PARQUET, COMPRESSION ZSTD)
        """
    )

    print("[3/8] Writing physically separated post-decision validation table", flush=True)
    con.execute(
        f"""
        COPY (
            SELECT
              concat(state_code, '-', cast(activity_year AS VARCHAR), '-',
                     lpad(cast(file_row_number AS VARCHAR), 10, '0')) AS application_row_id,
              cast(denied AS TINYINT) AS y_denied,
              lei AS g_lender_lei,
              action_taken AS z_action_taken,
              denial_reason_1 AS z_denial_reason_1,
              denial_reason_2 AS z_denial_reason_2,
              denial_reason_3 AS z_denial_reason_3,
              denial_reason_4 AS z_denial_reason_4,
              purchaser_type_post_decision AS z_purchaser_type,
              interest_rate_post_decision AS z_interest_rate,
              rate_spread_post_decision AS z_rate_spread,
              total_loan_costs_post_decision AS z_total_loan_costs,
              origination_charges_post_decision AS z_origination_charges
            FROM {source}
            WHERE {main_scope} AND {binary} AND {homogeneous}
        ) TO '{q(POST_PATH)}' (FORMAT PARQUET, COMPRESSION ZSTD)
        """
    )

    print("[4/8] Writing broad binary-decision robustness table", flush=True)
    con.execute(
        f"""
        COPY (
            SELECT {shared_columns}, {audit_columns},
              loan_purpose AS x_loan_purpose,
              lien_status AS x_lien_status,
              occupancy_type AS x_occupancy_type,
              construction_method AS x_construction_method,
              reverse_mortgage AS x_reverse_mortgage,
              open_end_line_of_credit AS x_open_end_line_of_credit,
              business_or_commercial_purpose AS x_business_or_commercial_purpose,
              total_units AS x_total_units,
              derived_loan_product_type AS x_derived_loan_product_type,
              derived_dwelling_category AS x_derived_dwelling_category
            FROM {source}
            WHERE {main_scope} AND {binary}
        ) TO '{q(ROBUST_PATH)}' (FORMAT PARQUET, COMPRESSION ZSTD)
        """
    )

    print("[5/8] Building sample-flow and variable-dictionary reports", flush=True)
    flow_values = con.execute(
        f"""
        SELECT
          count(*) AS all_main,
          count(*) FILTER (WHERE {binary}) AS binary_decision,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1) AS purchase,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1) AS first_lien,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1 AND occupancy_type = 1) AS owner_occupied,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1 AND occupancy_type = 1 AND construction_method = 1) AS site_built,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1 AND occupancy_type = 1 AND construction_method = 1 AND business_or_commercial_purpose = 2) AS nonbusiness,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1 AND occupancy_type = 1 AND construction_method = 1 AND business_or_commercial_purpose = 2 AND reverse_mortgage = 2) AS nonreverse,
          count(*) FILTER (WHERE {binary} AND loan_purpose = 1 AND lien_status = 1 AND occupancy_type = 1 AND construction_method = 1 AND business_or_commercial_purpose = 2 AND reverse_mortgage = 2 AND open_end_line_of_credit = 2) AS closed_end,
          count(*) FILTER (WHERE {binary} AND {homogeneous}) AS one_unit_final
        FROM {source}
        WHERE {main_scope}
        """
    ).fetchone()
    flow_labels = [
        ("01", "CA/TX/NY, 2018-2024 all records", "all_main"),
        ("02", "Retain approval/denial actions 1,2,3,7", "binary_decision"),
        ("03", "Retain home-purchase purpose", "purchase"),
        ("04", "Retain first-lien applications", "first_lien"),
        ("05", "Retain owner-occupied applications", "owner_occupied"),
        ("06", "Retain site-built construction", "site_built"),
        ("07", "Exclude business/commercial purpose", "nonbusiness"),
        ("08", "Exclude reverse mortgages", "nonreverse"),
        ("09", "Exclude open-end lines of credit", "closed_end"),
        ("10", "Retain one-unit dwellings (main homogeneous sample)", "one_unit_final"),
    ]
    flow_rows = []
    previous = None
    for index, (step, rule, key) in enumerate(flow_labels):
        n = int(flow_values[index])
        flow_rows.append(
            {
                "step": step,
                "rule": rule,
                "remaining_n": n,
                "removed_at_step": "" if previous is None else previous - n,
                "retention_from_previous": "" if previous is None else round(n / previous, 6),
            }
        )
        previous = n
    write_csv(
        REPORT_DIR / "sample_flow.csv",
        flow_rows,
        ["step", "rule", "remaining_n", "removed_at_step", "retention_from_previous"],
    )

    dictionary_rows = []
    for variable, role, timing, description in VARIABLES:
        datasets = []
        if role in {"identifier", "outcome", "outcome_source", "model_feature", "missing_indicator"}:
            datasets.extend(["main_peer", "main_audit", "robustness_binary"])
        elif role in {"grouping", "audit_only", "protected_audit", "sensitivity_only"}:
            datasets.extend(["main_audit", "robustness_binary"])
        elif role in {"validation_only", "post_decision"}:
            datasets.append("post_decision_validation")
        elif role == "robustness_feature":
            datasets.append("robustness_binary")
        dictionary_rows.append(
            {
                "variable": variable,
                "role": role,
                "timing": timing,
                "datasets": ";".join(datasets),
                "eligible_for_peer_model": "yes" if role in {"model_feature", "missing_indicator"} else "no",
                "description": description,
            }
        )
    write_csv(
        REPORT_DIR / "variable_dictionary.csv",
        dictionary_rows,
        ["variable", "role", "timing", "datasets", "eligible_for_peer_model", "description"],
    )

    print("[6/8] Calculating missingness and distribution diagnostics", flush=True)
    con.execute(f"CREATE OR REPLACE TEMP VIEW qa_audit AS SELECT * FROM read_parquet('{q(AUDIT_PATH)}')")
    qa_columns = [row[0] for row in con.execute("DESCRIBE qa_audit").fetchall() if row[0] != "application_row_id"]
    unavailable_conditions = {
        "x_dti_category": "x_dti_category IS NULL OR x_dti_category = 'Exempt'",
        "a_derived_race": "a_derived_race = 'Race Not Available'",
        "a_derived_ethnicity": "a_derived_ethnicity = 'Ethnicity Not Available'",
        "a_derived_sex": "a_derived_sex = 'Sex Not Available'",
        "a_applicant_age": "a_applicant_age IN ('8888', '9999')",
        "a_coapplicant_age": "a_coapplicant_age IN ('8888', '9999')",
    }
    aggregates = ["count(*) AS total_n"]
    for col in qa_columns:
        aggregates.append(f"count(*) FILTER (WHERE {col} IS NULL) AS \"{col}__null\"")
        aggregates.append(f"approx_count_distinct({col}) AS \"{col}__distinct\"")
        condition = unavailable_conditions.get(col, "FALSE")
        aggregates.append(f"count(*) FILTER (WHERE {condition}) AS \"{col}__unavailable\"")
    cursor = con.execute("SELECT " + ", ".join(aggregates) + " FROM qa_audit")
    values = cursor.fetchone()
    names = [d[0] for d in cursor.description]
    result = dict(zip(names, values))
    total_n = int(result["total_n"])
    missing_rows = []
    for col in qa_columns:
        null_n = int(result[f"{col}__null"])
        unavailable_n = int(result[f"{col}__unavailable"])
        missing_rows.append(
            {
                "variable": col,
                "total_n": total_n,
                "null_n": null_n,
                "null_rate": round(null_n / total_n, 8),
                "unavailable_or_exempt_n": unavailable_n,
                "unavailable_or_exempt_rate": round(unavailable_n / total_n, 8),
                "approx_distinct_n": int(result[f"{col}__distinct"]),
            }
        )
    write_csv(
        REPORT_DIR / "missingness_main.csv",
        missing_rows,
        [
            "variable",
            "total_n",
            "null_n",
            "null_rate",
            "unavailable_or_exempt_n",
            "unavailable_or_exempt_rate",
            "approx_distinct_n",
        ],
    )

    numeric_columns = [
        "x_loan_amount",
        "x_ltv",
        "x_property_value",
        "x_income_thousands",
        "x_tract_population",
        "x_ffiec_msa_median_family_income",
        "x_tract_to_msa_income_pct",
        "x_tract_owner_occupied_units",
        "x_tract_one_to_four_family_homes",
        "x_tract_median_housing_age",
        "a_tract_minority_population_pct",
    ]
    numeric_exprs = []
    for col in numeric_columns:
        numeric_exprs.extend(
            [
                f"count({col}) AS \"{col}__n\"",
                f"min({col}) AS \"{col}__min\"",
                f"max({col}) AS \"{col}__max\"",
                f"avg({col}) AS \"{col}__mean\"",
                f"stddev_samp({col}) AS \"{col}__sd\"",
                f"approx_quantile({col}, [0.001,0.01,0.25,0.5,0.75,0.99,0.999]) AS \"{col}__q\"",
                f"count(*) FILTER (WHERE {col} <= 0) AS \"{col}__nonpositive\"",
            ]
        )
    cursor = con.execute("SELECT " + ", ".join(numeric_exprs) + " FROM qa_audit")
    values = cursor.fetchone()
    names = [d[0] for d in cursor.description]
    result = dict(zip(names, values))
    outlier_rows = []
    for col in numeric_columns:
        quantiles = result[f"{col}__q"] or [None] * 7
        outlier_rows.append(
            {
                "variable": col,
                "nonmissing_n": result[f"{col}__n"],
                "min": result[f"{col}__min"],
                "p0_1": quantiles[0],
                "p1": quantiles[1],
                "p25": quantiles[2],
                "median": quantiles[3],
                "p75": quantiles[4],
                "p99": quantiles[5],
                "p99_9": quantiles[6],
                "max": result[f"{col}__max"],
                "mean": result[f"{col}__mean"],
                "sd": result[f"{col}__sd"],
                "nonpositive_n": result[f"{col}__nonpositive"],
            }
        )
    write_csv(
        REPORT_DIR / "numeric_diagnostics_main.csv",
        outlier_rows,
        ["variable", "nonmissing_n", "min", "p0_1", "p1", "p25", "median", "p75", "p99", "p99_9", "max", "mean", "sd", "nonpositive_n"],
    )

    category_columns = [
        "y_denied",
        "x_activity_year",
        "x_state_code",
        "x_preapproval",
        "x_loan_type",
        "x_dti_category",
        "a_derived_race",
        "a_derived_ethnicity",
        "a_derived_sex",
        "a_applicant_age",
    ]
    category_rows = []
    for col in category_columns:
        rows = con.execute(
            f"SELECT cast({col} AS VARCHAR), count(*) FROM qa_audit GROUP BY 1 ORDER BY 2 DESC"
        ).fetchall()
        for value, count in rows:
            category_rows.append(
                {
                    "variable": col,
                    "value": "<NULL>" if value is None else value,
                    "n": int(count),
                    "share": round(count / total_n, 8),
                }
            )
    write_csv(
        REPORT_DIR / "categorical_distributions_main.csv",
        category_rows,
        ["variable", "value", "n", "share"],
    )

    print("[7/8] Registering modeling views and validating artifacts", flush=True)
    con.execute(f"CREATE OR REPLACE VIEW model_main_peer AS SELECT * FROM read_parquet('{q(PEER_PATH)}')")
    con.execute(f"CREATE OR REPLACE VIEW model_main_audit AS SELECT * FROM read_parquet('{q(AUDIT_PATH)}')")
    con.execute(f"CREATE OR REPLACE VIEW model_post_decision_validation AS SELECT * FROM read_parquet('{q(POST_PATH)}')")
    con.execute(f"CREATE OR REPLACE VIEW model_robustness_binary AS SELECT * FROM read_parquet('{q(ROBUST_PATH)}')")

    counts = {
        "peer_rows": con.execute("SELECT count(*) FROM model_main_peer").fetchone()[0],
        "audit_rows": con.execute("SELECT count(*) FROM model_main_audit").fetchone()[0],
        "post_rows": con.execute("SELECT count(*) FROM model_post_decision_validation").fetchone()[0],
        "robustness_rows": con.execute("SELECT count(*) FROM model_robustness_binary").fetchone()[0],
        "peer_denied": con.execute("SELECT sum(y_denied) FROM model_main_peer").fetchone()[0],
        "peer_distinct_ids": con.execute("SELECT count(DISTINCT application_row_id) FROM model_main_peer").fetchone()[0],
        "audit_distinct_ids": con.execute("SELECT count(DISTINCT application_row_id) FROM model_main_audit").fetchone()[0],
        "peer_invalid_outcome": con.execute("SELECT count(*) FROM model_main_peer WHERE y_denied NOT IN (0,1) OR y_denied IS NULL").fetchone()[0],
    }
    peer_columns = [r[0] for r in con.execute("DESCRIBE model_main_peer").fetchall()]
    audit_columns_actual = [r[0] for r in con.execute("DESCRIBE model_main_audit").fetchall()]
    checks = {
        "main_expected_rows": counts["peer_rows"] == 5_841_923,
        "main_expected_denied": counts["peer_denied"] == 548_719,
        "all_main_artifacts_same_rows": counts["peer_rows"] == counts["audit_rows"] == counts["post_rows"],
        "robustness_expected_rows": counts["robustness_rows"] == 19_531_386,
        "peer_ids_unique": counts["peer_distinct_ids"] == counts["peer_rows"],
        "audit_ids_unique": counts["audit_distinct_ids"] == counts["audit_rows"],
        "outcome_valid": counts["peer_invalid_outcome"] == 0,
        "peer_has_no_group_protected_or_post_columns": not any(c.startswith(("g_", "a_", "z_", "s_")) for c in peer_columns),
        "audit_has_no_post_decision_columns": not any(c.startswith("z_") for c in audit_columns_actual),
    }
    status = "PASS" if all(checks.values()) else "FAIL"

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS modeling_artifact_registry (
          artifact_name VARCHAR PRIMARY KEY,
          file_path VARCHAR,
          row_count BIGINT,
          sha256 VARCHAR,
          created_at_utc TIMESTAMP
        )
        """
    )
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    for name, path, row_count in [
        ("main_peer", PEER_PATH, counts["peer_rows"]),
        ("main_audit", AUDIT_PATH, counts["audit_rows"]),
        ("post_decision_validation", POST_PATH, counts["post_rows"]),
        ("robustness_binary", ROBUST_PATH, counts["robustness_rows"]),
    ]:
        con.execute("DELETE FROM modeling_artifact_registry WHERE artifact_name = ?", [name])
        con.execute(
            "INSERT INTO modeling_artifact_registry VALUES (?, ?, ?, ?, ?)",
            [name, str(path), row_count, sha256_file(path), now],
        )

    report = {
        "status": status,
        "started_at_utc": datetime.fromtimestamp(started, timezone.utc).isoformat(),
        "finished_at_utc": datetime.now(timezone.utc).isoformat(),
        "duration_seconds": round(time.time() - started, 2),
        "source_database": str(DB_PATH),
        "counts": counts,
        "checks": checks,
        "artifacts": {
            name: {
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
            for name, path in [
                ("main_peer", PEER_PATH),
                ("main_audit", AUDIT_PATH),
                ("post_decision_validation", POST_PATH),
                ("robustness_binary", ROBUST_PATH),
            ]
        },
        "reports": [
            str(REPORT_DIR / "sample_flow.csv"),
            str(REPORT_DIR / "variable_dictionary.csv"),
            str(REPORT_DIR / "missingness_main.csv"),
            str(REPORT_DIR / "numeric_diagnostics_main.csv"),
            str(REPORT_DIR / "categorical_distributions_main.csv"),
        ],
        "leakage_policy": {
            "peer_allowed_prefixes": ["x_"],
            "outcome_prefix": "y_",
            "model_target": "y_denied",
            "selection_only_outcome_source": "y_action_taken_code",
            "identifier": "application_row_id",
            "audit_only_prefixes": ["g_", "a_", "s_"],
            "post_decision_prefix": "z_",
            "post_decision_physically_separated": True,
        },
    }
    LOG_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    con.close()

    print("[8/8] Complete", flush=True)
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    if status != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
