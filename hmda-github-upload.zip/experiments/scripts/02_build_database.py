from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "experiments" / "vendor"))
import duckdb  # noqa: E402


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(chunk_size):
            digest.update(chunk)
    return digest.hexdigest()


def q(path: Path) -> str:
    return str(path).replace("'", "''").replace("\\", "/")


def build(year: int, state: str) -> None:
    state = state.upper()
    raw_csv = PROJECT_ROOT / "data" / "data" / "raw" / "hmda" / f"year={year}" / f"hmda_{state}_{year}.csv"
    if not raw_csv.exists():
        raise FileNotFoundError(f"Run 01_download_hmda.py first: {raw_csv}")

    parquet_dir = PROJECT_ROOT / "data" / "data" / "processed" / "hmda" / f"state={state}" / f"year={year}"
    parquet_dir.mkdir(parents=True, exist_ok=True)
    parquet_path = parquet_dir / "data.parquet"
    db_path = PROJECT_ROOT / "data" / "database" / "hmda.duckdb"

    con = duckdb.connect(str(db_path))
    con.execute("PRAGMA threads=4")
    con.execute("PRAGMA preserve_insertion_order=false")

    con.execute(
        """
        CREATE TABLE IF NOT EXISTS etl_registry (
            year INTEGER,
            state VARCHAR,
            source_file VARCHAR,
            source_sha256 VARCHAR,
            source_bytes BIGINT,
            row_count BIGINT,
            imported_at_utc TIMESTAMP,
            parquet_file VARCHAR,
            PRIMARY KEY (year, state)
        )
        """
    )
    con.execute(
        """
        CREATE OR REPLACE TABLE dim_denial_reason AS
        SELECT * FROM (VALUES
          (1, 'Debt-to-income ratio'),
          (2, 'Employment history'),
          (3, 'Credit history'),
          (4, 'Collateral'),
          (5, 'Insufficient cash'),
          (6, 'Unverifiable information'),
          (7, 'Credit application incomplete'),
          (8, 'Mortgage insurance denied'),
          (9, 'Other'),
          (10, 'Not applicable')
        ) AS t(reason_code, reason_label)
        """
    )

    raw = q(raw_csv)
    out = q(parquet_path)
    select_sql = f"""
        SELECT
          try_cast(activity_year AS INTEGER) AS activity_year,
          lei,
          state_code,
          county_code,
          census_tract,
          "derived_msa-md" AS derived_msa_md,
          derived_loan_product_type,
          derived_dwelling_category,
          derived_ethnicity,
          derived_race,
          derived_sex,
          try_cast(action_taken AS INTEGER) AS action_taken,
          CASE WHEN try_cast(action_taken AS INTEGER) IN (3, 7) THEN 1
               WHEN try_cast(action_taken AS INTEGER) IN (1, 2) THEN 0 END AS denied,
          CASE WHEN try_cast(action_taken AS INTEGER) IN (1, 2, 3, 7) THEN 1 ELSE 0 END AS binary_decision_sample,
          try_cast(preapproval AS INTEGER) AS preapproval,
          try_cast(loan_type AS INTEGER) AS loan_type,
          try_cast(loan_purpose AS INTEGER) AS loan_purpose,
          try_cast(lien_status AS INTEGER) AS lien_status,
          try_cast(reverse_mortgage AS INTEGER) AS reverse_mortgage,
          try_cast("open-end_line_of_credit" AS INTEGER) AS open_end_line_of_credit,
          try_cast(business_or_commercial_purpose AS INTEGER) AS business_or_commercial_purpose,
          try_cast(loan_amount AS DOUBLE) AS loan_amount,
          try_cast(NULLIF(loan_to_value_ratio, 'NA') AS DOUBLE) AS loan_to_value_ratio,
          try_cast(NULLIF(property_value, 'NA') AS DOUBLE) AS property_value,
          try_cast(NULLIF(income, 'NA') AS DOUBLE) AS income_thousands,
          debt_to_income_ratio,
          applicant_credit_score_type,
          "co-applicant_credit_score_type" AS co_applicant_credit_score_type,
          applicant_age,
          "co-applicant_age" AS co_applicant_age,
          applicant_age_above_62,
          "co-applicant_age_above_62" AS co_applicant_age_above_62,
          try_cast(applicant_sex AS INTEGER) AS applicant_sex_code,
          try_cast("applicant_ethnicity-1" AS INTEGER) AS applicant_ethnicity_1,
          try_cast("applicant_race-1" AS INTEGER) AS applicant_race_1,
          try_cast(occupancy_type AS INTEGER) AS occupancy_type,
          try_cast(construction_method AS INTEGER) AS construction_method,
          total_units,
          try_cast("denial_reason-1" AS INTEGER) AS denial_reason_1,
          try_cast("denial_reason-2" AS INTEGER) AS denial_reason_2,
          try_cast("denial_reason-3" AS INTEGER) AS denial_reason_3,
          try_cast("denial_reason-4" AS INTEGER) AS denial_reason_4,
          try_cast(tract_population AS BIGINT) AS tract_population,
          try_cast(tract_minority_population_percent AS DOUBLE) AS tract_minority_population_percent,
          try_cast(ffiec_msa_md_median_family_income AS DOUBLE) AS ffiec_msa_md_median_family_income,
          try_cast(tract_to_msa_income_percentage AS DOUBLE) AS tract_to_msa_income_percentage,
          try_cast(tract_owner_occupied_units AS BIGINT) AS tract_owner_occupied_units,
          try_cast(tract_one_to_four_family_homes AS BIGINT) AS tract_one_to_four_family_homes,
          try_cast(tract_median_age_of_housing_units AS DOUBLE) AS tract_median_age_of_housing_units,
          -- Kept for secondary analyses, but excluded from the main ex-ante denial model.
          try_cast(purchaser_type AS INTEGER) AS purchaser_type_post_decision,
          try_cast(NULLIF(interest_rate, 'NA') AS DOUBLE) AS interest_rate_post_decision,
          try_cast(NULLIF(rate_spread, 'NA') AS DOUBLE) AS rate_spread_post_decision,
          try_cast(NULLIF(total_loan_costs, 'NA') AS DOUBLE) AS total_loan_costs_post_decision,
          try_cast(NULLIF(origination_charges, 'NA') AS DOUBLE) AS origination_charges_post_decision
        FROM read_csv('{raw}', header=true, all_varchar=true, ignore_errors=false)
    """
    con.execute(f"COPY ({select_sql}) TO '{out}' (FORMAT PARQUET, COMPRESSION ZSTD)")
    row_count = con.execute(f"SELECT count(*) FROM read_parquet('{out}')").fetchone()[0]

    con.execute(
        "DELETE FROM etl_registry WHERE year = ? AND state = ?",
        [year, state],
    )
    con.execute(
        """
        INSERT INTO etl_registry VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        [
            year,
            state,
            str(raw_csv),
            sha256_file(raw_csv),
            raw_csv.stat().st_size,
            row_count,
            datetime.now(timezone.utc).replace(tzinfo=None),
            str(parquet_path),
        ],
    )

    glob_path = q(PROJECT_ROOT / "data" / "data" / "processed" / "hmda" / "state=*" / "year=*" / "data.parquet")
    con.execute(
        f"CREATE OR REPLACE VIEW hmda_all AS SELECT * FROM read_parquet('{glob_path}', union_by_name=true)"
    )
    con.execute(
        "CREATE OR REPLACE VIEW hmda_binary_decision AS SELECT * FROM hmda_all WHERE binary_decision_sample = 1"
    )
    config = json.loads((PROJECT_ROOT / "experiments" / "config" / "project.json").read_text(encoding="utf-8"))
    states = ", ".join(f"'{x}'" for x in config["planned_main_sample"]["states"])
    years = ", ".join(str(x) for x in config["planned_main_sample"]["years"])
    con.execute(
        f"""
        CREATE OR REPLACE VIEW hmda_main_all AS
        SELECT * FROM hmda_all
        WHERE state_code IN ({states}) AND activity_year IN ({years})
        """
    )
    con.execute(
        """
        CREATE OR REPLACE VIEW hmda_main_binary_decision AS
        SELECT * FROM hmda_main_all WHERE binary_decision_sample = 1
        """
    )
    con.execute(
        """
        CREATE OR REPLACE VIEW hmda_homogeneous_sample AS
        SELECT * FROM hmda_main_binary_decision
        WHERE loan_purpose = 1
          AND lien_status = 1
          AND occupancy_type = 1
          AND construction_method = 1
          AND business_or_commercial_purpose = 2
          AND reverse_mortgage = 2
          AND open_end_line_of_credit = 2
          AND total_units = '1'
        """
    )
    con.close()

    result = {
        "year": year,
        "state": state,
        "rows": row_count,
        "raw_bytes": raw_csv.stat().st_size,
        "parquet_bytes": parquet_path.stat().st_size,
        "database": str(db_path),
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description="Convert an HMDA CSV to Parquet and update DuckDB.")
    parser.add_argument("--year", type=int, required=True)
    parser.add_argument("--state", required=True)
    args = parser.parse_args()
    build(args.year, args.state)


if __name__ == "__main__":
    main()
