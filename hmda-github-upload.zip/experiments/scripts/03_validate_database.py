from __future__ import annotations

import json
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "experiments" / "vendor"))
import duckdb  # noqa: E402


def scalar(con: duckdb.DuckDBPyConnection, sql: str):
    return con.execute(sql).fetchone()[0]


def main() -> None:
    db_path = PROJECT_ROOT / "data" / "database" / "hmda.duckdb"
    if not db_path.exists():
        raise FileNotFoundError("Database not found. Run 02_build_database.py first.")
    con = duckdb.connect(str(db_path), read_only=True)

    total = scalar(con, "SELECT count(*) FROM hmda_all")
    binary = scalar(con, "SELECT count(*) FROM hmda_binary_decision")
    denied = scalar(con, "SELECT count(*) FROM hmda_binary_decision WHERE denied = 1")
    approved = scalar(con, "SELECT count(*) FROM hmda_binary_decision WHERE denied = 0")
    invalid_outcomes = scalar(
        con,
        "SELECT count(*) FROM hmda_binary_decision WHERE denied IS NULL OR action_taken NOT IN (1,2,3,7)",
    )
    invalid_years = scalar(con, "SELECT count(*) FROM hmda_all WHERE activity_year IS NULL")
    invalid_states = scalar(con, "SELECT count(*) FROM hmda_all WHERE state_code IS NULL")
    duplicate_registry = scalar(
        con,
        "SELECT count(*) FROM (SELECT year, state, count(*) n FROM etl_registry GROUP BY 1,2 HAVING n > 1)",
    )
    main_total = scalar(con, "SELECT count(*) FROM hmda_main_all")
    main_binary = scalar(con, "SELECT count(*) FROM hmda_main_binary_decision")
    homogeneous = scalar(con, "SELECT count(*) FROM hmda_homogeneous_sample")
    homogeneous_denied = scalar(con, "SELECT count(*) FROM hmda_homogeneous_sample WHERE denied = 1")
    imported_main_cells = scalar(
        con,
        "SELECT count(*) FROM etl_registry WHERE state IN ('CA','TX','NY') AND year BETWEEN 2018 AND 2024",
    )

    report = {
        "total_rows": total,
        "binary_decision_rows": binary,
        "approved_rows": approved,
        "denied_rows": denied,
        "denial_rate": round(denied / binary, 6) if binary else None,
        "main_sample": {
            "all_rows": main_total,
            "binary_decision_rows": main_binary,
            "homogeneous_rows": homogeneous,
            "homogeneous_denied_rows": homogeneous_denied,
            "homogeneous_denial_rate": round(homogeneous_denied / homogeneous, 6) if homogeneous else None,
            "imported_state_year_cells": imported_main_cells,
            "expected_state_year_cells": 21
        },
        "checks": {
            "invalid_binary_outcomes": invalid_outcomes,
            "missing_activity_year": invalid_years,
            "missing_state_code": invalid_states,
            "duplicate_registry_keys": duplicate_registry,
        },
        "status": "PASS" if all(x == 0 for x in [invalid_outcomes, invalid_years, invalid_states, duplicate_registry]) else "FAIL",
    }
    output = PROJECT_ROOT / "experiments" / "logs" / "database_validation.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    con.close()


if __name__ == "__main__":
    main()
