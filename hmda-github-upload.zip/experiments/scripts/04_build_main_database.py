from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import time
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PYTHON = Path(sys.executable)
CONFIG = json.loads((PROJECT_ROOT / "experiments" / "config" / "project.json").read_text(encoding="utf-8"))
STATES = CONFIG["planned_main_sample"]["states"]
YEARS = CONFIG["planned_main_sample"]["years"]
LOG_PATH = PROJECT_ROOT / "experiments" / "logs" / "main_database_build.json"


def run_command(command: list[str]) -> dict:
    started = time.time()
    proc = subprocess.run(command, cwd=PROJECT_ROOT, text=True, capture_output=True)
    return {
        "command": command,
        "exit_code": proc.returncode,
        "duration_seconds": round(time.time() - started, 2),
        "stdout": proc.stdout[-4000:],
        "stderr": proc.stderr[-4000:],
    }


def current_download_bytes() -> int:
    raw_root = PROJECT_ROOT / "data" / "data" / "raw" / "hmda"
    return sum(p.stat().st_size for p in raw_root.rglob("*.csv*"))


def download_all(workers: int) -> list[dict]:
    tasks = [(state, year) for year in YEARS for state in STATES]
    results: list[dict] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        task_iter = iter(tasks)
        futures = {}
        for _ in range(min(workers, len(tasks))):
            state, year = next(task_iter)
            future = pool.submit(
                run_command,
                [str(PYTHON), str(PROJECT_ROOT / "experiments" / "scripts" / "01_download_hmda.py"), "--year", str(year), "--state", state],
            )
            futures[future] = (state, year)
        pending = set(futures)
        while pending:
            done, pending = wait(pending, timeout=30, return_when=FIRST_COMPLETED)
            for future in done:
                state, year = futures[future]
                result = future.result()
                result.update({"state": state, "year": year, "stage": "download"})
                results.append(result)
                print(f"[DOWNLOAD] {state} {year}: exit={result['exit_code']} duration={result['duration_seconds']}s", flush=True)
                if result["exit_code"] != 0:
                    for queued in pending:
                        queued.cancel()
                    raise RuntimeError(f"Download failed for {state} {year}: {result['stderr']}")
                try:
                    next_state, next_year = next(task_iter)
                except StopIteration:
                    continue
                next_future = pool.submit(
                    run_command,
                    [
                        str(PYTHON),
                        str(PROJECT_ROOT / "experiments" / "scripts" / "01_download_hmda.py"),
                        "--year",
                        str(next_year),
                        "--state",
                        next_state,
                    ],
                )
                futures[next_future] = (next_state, next_year)
                pending.add(next_future)
            if not done:
                free_gb = shutil.disk_usage(PROJECT_ROOT).free / 1024**3
                downloaded_gb = current_download_bytes() / 1024**3
                print(
                    f"[MONITOR] downloads complete={len(results)}/{len(tasks)} stored={downloaded_gb:.2f}GB free={free_gb:.2f}GB",
                    flush=True,
                )
    return results


def build_all() -> list[dict]:
    results: list[dict] = []
    total = len(STATES) * len(YEARS)
    completed = 0
    for year in YEARS:
        for state in STATES:
            result = run_command(
                [str(PYTHON), str(PROJECT_ROOT / "experiments" / "scripts" / "02_build_database.py"), "--year", str(year), "--state", state]
            )
            result.update({"state": state, "year": year, "stage": "build"})
            results.append(result)
            completed += 1
            print(f"[BUILD] {state} {year}: exit={result['exit_code']} ({completed}/{total})", flush=True)
            if result["exit_code"] != 0:
                raise RuntimeError(f"Build failed for {state} {year}: {result['stderr']}")
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the CA/TX/NY 2018-2024 HMDA database.")
    parser.add_argument("--download-workers", type=int, default=3)
    parser.add_argument("--skip-download", action="store_true")
    parser.add_argument("--skip-build", action="store_true")
    args = parser.parse_args()

    started_at = datetime.now(timezone.utc)
    report = {
        "started_at_utc": started_at.isoformat(),
        "states": STATES,
        "years": YEARS,
        "download_workers": args.download_workers,
        "downloads": [],
        "builds": [],
        "status": "running",
    }
    try:
        if not args.skip_download:
            report["downloads"] = download_all(args.download_workers)
        if not args.skip_build:
            report["builds"] = build_all()
        validation = run_command([str(PYTHON), str(PROJECT_ROOT / "experiments" / "scripts" / "03_validate_database.py")])
        report["validation"] = validation
        if validation["exit_code"] != 0:
            raise RuntimeError(validation["stderr"])
        print(validation["stdout"], flush=True)
        report["status"] = "completed"
    except Exception as exc:
        report["status"] = "crashed"
        report["error"] = str(exc)
        raise
    finally:
        report["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        LOG_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
