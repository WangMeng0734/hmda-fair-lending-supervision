"""Unified regularized-logistic benchmark for the HMDA study.

Formal full-sample run:
    python run_logistic.py

Independent smoke test (at most 50,000 observations per year):
    python run_logistic.py --smoke-test --output-mode overwrite

The Logistic benchmark deliberately contains no SHAP, PDP/ALE, permutation
importance, coefficient interpretation, or protected-group audit. It saves only
the fitted model, predictions, comparison metrics, and basic evaluation curves.
"""

from __future__ import annotations

import argparse
import gc
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import joblib
    import pyarrow
    import pyarrow.parquet as pq
    import sklearn
    from sklearn.compose import ColumnTransformer
    from sklearn.impute import SimpleImputer
    from sklearn.linear_model import SGDClassifier
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder, StandardScaler
except ImportError as exc:
    raise SystemExit(
        "Missing dependency. In the VSCode Base terminal run:\n"
        "python -m pip install scikit-learn pandas pyarrow numpy scipy joblib "
        "matplotlib statsmodels\n"
        f"Import error: {exc}"
    ) from exc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "data" / "data" / "modeling" / "main_homogeneous_peer.parquet"
REPORTING_DIR = HERE.parent / "03_lightgbm_optuna"
if str(REPORTING_DIR) not in sys.path:
    sys.path.insert(0, str(REPORTING_DIR))

from model_reporting import (  # noqa: E402
    bootstrap_cis,
    calibration_bins,
    choose_youden_threshold,
    classification_metrics,
    confusion_tables,
    ensure_dirs,
    make_m2,
    make_m3,
    make_m4,
    threshold_metrics,
    write_table,
)


SEED = 20260731
OUT = HERE / "results"


def make_encoder():
    try:
        return OneHotEncoder(
            handle_unknown="ignore", sparse_output=True, dtype=np.float32
        )
    except TypeError:  # scikit-learn < 1.2
        return OneHotEncoder(
            handle_unknown="ignore", sparse=True, dtype=np.float32
        )


def logistic_loss_name():
    major_minor = tuple(int(part) for part in sklearn.__version__.split(".")[:2])
    return "log_loss" if major_minor >= (1, 1) else "log"


def make_model(numeric, categorical):
    numeric_pipe = Pipeline([
        ("impute", SimpleImputer(strategy="median", add_indicator=True)),
        ("scale", StandardScaler(with_mean=False)),
    ])
    categorical_pipe = Pipeline([
        ("impute", SimpleImputer(strategy="constant", fill_value="__MISSING__")),
        ("onehot", make_encoder()),
    ])
    preprocess = ColumnTransformer([
        ("numeric", numeric_pipe, numeric),
        ("categorical", categorical_pipe, categorical),
    ], sparse_threshold=1.0)
    classifier = SGDClassifier(
        loss=logistic_loss_name(), penalty="l2", alpha=1e-6,
        max_iter=100, tol=1e-4, average=True,
        random_state=SEED, n_jobs=-1,
    )
    return Pipeline([
        ("preprocess", preprocess),
        ("logistic", classifier),
    ])


def natural_sample_by_year(frame, max_rows):
    if not max_rows:
        return frame
    sampled = []
    for _, group in frame.groupby("x_activity_year", sort=True):
        sampled.append(group.sample(min(len(group), max_rows), random_state=SEED))
    return pd.concat(sampled, ignore_index=True)


def prepare_output(path, mode):
    path = path.resolve()
    if path.parent != HERE.resolve():
        raise RuntimeError(f"Unsafe output target: {path}")
    selected = mode
    existing = path.exists() and any(path.iterdir())
    if existing and mode == "ask":
        try:
            choice = input(
                f"\nExisting Logistic output found: {path}\n"
                "Choose [1] overwrite or [2] cancel (default: 2): "
            ).strip().lower()
        except EOFError:
            choice = "2"
        selected = "overwrite" if choice in {"1", "o", "overwrite"} else "cancel"
    elif not existing and mode == "ask":
        selected = "overwrite"
    if selected == "cancel":
        print("Run cancelled; existing Logistic outputs were not changed.")
        return False
    if selected == "overwrite" and path.exists():
        shutil.rmtree(path)
    ensure_dirs(path)
    return True


def table_from_mapping(mapping):
    return pd.DataFrame([
        {
            "item": key,
            "value": json.dumps(value, ensure_ascii=False)
            if isinstance(value, (dict, list)) else value,
        }
        for key, value in mapping.items()
    ])


def build_excel_workbook(out_dir):
    builder = REPORTING_DIR / "build_optuna_workbook.mjs"
    node = shutil.which("node")
    if node is None:
        bundled = (
            Path.home() / ".cache" / "codex-runtimes" /
            "codex-primary-runtime" / "dependencies" / "node" / "bin" / "node.exe"
        )
        if bundled.exists():
            node = str(bundled)
    if node is None or not builder.exists():
        print("Excel build skipped: bundled Node runtime or workbook builder was not found.")
        return False
    try:
        subprocess.run([str(node), str(builder), str(out_dir)], check=True)
        return True
    except subprocess.CalledProcessError as exc:
        print(f"Excel build failed, but CSV/Parquet outputs are intact: {exc}")
        return False


def write_smoke_report(out_dir, excel_ok, elapsed_seconds):
    expected_figures = ["Figure_M2", "Figure_M3", "Figure_M4"]
    checks = []
    for figure in expected_figures:
        for fmt in ("png", "pdf", "svg"):
            path = Path(out_dir) / "figures" / fmt / f"{figure}.{fmt}"
            checks.append({
                "check": f"{figure}.{fmt}",
                "passed": path.exists() and path.stat().st_size > 0,
            })
    checks.extend([
        {
            "check": "model",
            "passed": (Path(out_dir) / "models" / "logistic_baseline.joblib").exists(),
        },
        {
            "check": "workbook",
            "passed": bool(excel_ok) and (Path(out_dir) / "model_results.xlsx").exists(),
        },
        {
            "check": "metrics",
            "passed": all(
                (Path(out_dir) / "tables" / f"Metrics_{name}.csv").exists()
                for name in ("Train", "Validation_2023", "Test_2024")
            ),
        },
    ])
    payload = {
        "verdict": "PASS" if all(item["passed"] for item in checks) else "FAIL",
        "elapsed_seconds": elapsed_seconds,
        "checks": checks,
    }
    (Path(out_dir) / "smoke_test_report.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (Path(out_dir) / "smoke_test_report.md").write_text(
        "# Logistic benchmark smoke-test report\n\n"
        f"- Verdict: {payload['verdict']}\n"
        f"- Elapsed seconds: {elapsed_seconds:.1f}\n"
        "- Figures: 3\n",
        encoding="utf-8",
    )
    return payload["verdict"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--max-rows-per-year", type=int, default=None,
        help="Optional natural-distribution sample for a test run.",
    )
    parser.add_argument(
        "--smoke-test", action="store_true",
        help="Run the complete workflow on at most 50,000 rows per year.",
    )
    parser.add_argument(
        "--output-mode", choices=["ask", "overwrite", "cancel"], default="ask",
        help="How to handle an existing Logistic output directory.",
    )
    args, unknown_args = parser.parse_known_args()
    if unknown_args:
        print(f"Ignoring VSCode/Jupyter arguments: {unknown_args}")
    if args.smoke_test:
        args.max_rows_per_year = 50000

    global OUT
    OUT = HERE / ("smoke_test" if args.smoke_test else "results")
    if not prepare_output(OUT, args.output_mode):
        return
    started = time.time()
    runtime_log = [{
        "stage": "run_started", "status": "OK", "elapsed_seconds": 0.0,
        "detail": "Metric-only Logistic benchmark initialized",
    }]

    if not DATA.exists():
        raise FileNotFoundError(f"Modeling data not found: {DATA}")
    schema = pq.ParquetFile(DATA).schema.names
    features = [c for c in schema if c.startswith("x_") and c != "x_activity_year"]
    columns = ["application_row_id", "y_denied", "x_activity_year", *features]
    df = pd.read_parquet(DATA, columns=list(dict.fromkeys(columns)), engine="pyarrow")
    df["y_denied"] = pd.to_numeric(df.y_denied, errors="raise").astype("int8")
    df["x_activity_year"] = pd.to_numeric(
        df.x_activity_year, errors="raise"
    ).astype("int16")
    df = natural_sample_by_year(df, args.max_rows_per_year)

    categorical = [c for c in [
        "x_state_code", "x_county_code", "x_msa_md", "x_preapproval",
        "x_loan_type", "x_dti_category",
    ] if c in features]
    numeric = [c for c in features if c not in categorical]
    threshold_train = df[df.x_activity_year.between(2018, 2021)].copy()
    threshold_valid = df[df.x_activity_year == 2022].copy()
    final_train = df[df.x_activity_year.between(2018, 2022)].copy()
    valid = df[df.x_activity_year == 2023].copy()
    test = df[df.x_activity_year == 2024].copy()
    del df
    gc.collect()

    print(f"Threshold train 2018-2021: {len(threshold_train):,}")
    print(f"Threshold validation 2022: {len(threshold_valid):,}")
    print(f"Final train 2018-2022: {len(final_train):,}")
    print(f"External validation 2023: {len(valid):,}")
    print(f"Final test 2024: {len(test):,}")
    print("Protected attributes are excluded from the prediction model.")

    threshold_model = make_model(numeric, categorical)
    threshold_model.fit(threshold_train[features], threshold_train.y_denied)
    p_threshold = threshold_model.predict_proba(threshold_valid[features])[:, 1]
    y_threshold = threshold_valid.y_denied.to_numpy(copy=True)
    threshold_valid[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_threshold
    ).to_parquet(
        OUT / "source_data" / "predictions_2022_threshold_selection.parquet",
        index=False,
    )
    del threshold_model, threshold_train, threshold_valid
    gc.collect()

    model = make_model(numeric, categorical)
    model.fit(final_train[features], final_train.y_denied)
    p_train = model.predict_proba(final_train[features])[:, 1]
    p_valid = model.predict_proba(valid[features])[:, 1]
    p_test = model.predict_proba(test[features])[:, 1]
    runtime_log.append({
        "stage": "final_model", "status": "OK",
        "elapsed_seconds": round(time.time() - started, 3),
        "detail": "Refit on 2018-2022 and generated comparison predictions",
    })

    for frame, probability, name in [
        (final_train, p_train, "predictions_train_2018_2022.parquet"),
        (valid, p_valid, "predictions_validation_2023.parquet"),
        (test, p_test, "predictions_test_2024.parquet"),
    ]:
        frame[["application_row_id", "x_activity_year", "y_denied"]].assign(
            predicted_probability=probability
        ).to_parquet(OUT / "source_data" / name, index=False)
    joblib.dump(model, OUT / "models" / "logistic_baseline.joblib", compress=3)

    bootstrap_reps = 20 if args.smoke_test else 500
    threshold = choose_youden_threshold(y_threshold, p_threshold)
    metrics_train = classification_metrics(
        final_train.y_denied, p_train, threshold, "2018-2022 train"
    )
    metrics_valid = classification_metrics(
        valid.y_denied, p_valid, threshold, "2023 validation"
    )
    metrics_test = classification_metrics(
        test.y_denied, p_test, threshold, "2024 test"
    )
    metrics_valid.update(bootstrap_cis(
        valid.y_denied, p_valid, threshold, bootstrap_reps, SEED + 1
    ))
    metrics_test.update(bootstrap_cis(
        test.y_denied, p_test, threshold, bootstrap_reps, SEED + 2
    ))
    metrics_comparison = pd.DataFrame([metrics_train, metrics_valid, metrics_test])
    calibration = pd.concat([
        calibration_bins(valid.y_denied, p_valid, "2023 validation"),
        calibration_bins(test.y_denied, p_test, "2024 test"),
    ], ignore_index=True)
    threshold_curve = threshold_metrics(test.y_denied, p_test)
    confusion_counts, confusion_rates = confusion_tables(
        test.y_denied, p_test, threshold
    )

    figure_files = []
    _, paths = make_m2(valid.y_denied, p_valid, test.y_denied, p_test, OUT)
    figure_files += paths
    _, paths = make_m3(
        calibration, test.y_denied, p_test, threshold,
        metrics_valid, metrics_test, OUT,
    )
    figure_files += paths
    _, paths = make_m4(
        confusion_counts, confusion_rates, threshold_curve, threshold, OUT
    )
    figure_files += paths
    figure_index = pd.DataFrame([{
        "figure": path.stem,
        "format": path.suffix.lstrip("."),
        "file": str(path.relative_to(OUT)),
        "size_bytes": path.stat().st_size,
        "source_data": f"source_data/{path.stem}.csv",
    } for path in figure_files])

    model_parameters = {
        "penalty": "l2", "alpha": 1e-6, "max_iter": 100,
        "tol": 1e-4, "average": True, "class_weight": None,
    }
    manifest = {
        "model": "L2-regularized logistic regression (SGD log loss)",
        "seed": SEED,
        "run_type": "smoke_test" if args.smoke_test else "formal",
        "sample_rows_per_year": args.max_rows_per_year,
        "features": features,
        "categorical_features": categorical,
        "numeric_features": numeric,
        "protected_attributes_in_model": False,
        "natural_class_distribution": True,
        "threshold_rule": "Maximize Youden J on 2022 only",
        "selected_threshold": threshold,
        "bootstrap_reps": bootstrap_reps,
        "model_parameters": model_parameters,
        "software_versions": {
            "python": sys.version.split()[0],
            "scikit_learn": sklearn.__version__,
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "pyarrow": pyarrow.__version__,
        },
    }
    (OUT / "run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    data_splits = pd.DataFrame([
        {"split": "Threshold train", "years": "2018-2021", "N": int((final_train.x_activity_year <= 2021).sum())},
        {"split": "Threshold validation", "years": "2022", "N": int((final_train.x_activity_year == 2022).sum())},
        {"split": "Final refit", "years": "2018-2022", "N": len(final_train)},
        {"split": "External validation", "years": "2023", "N": len(valid)},
        {"split": "Final test", "years": "2024", "N": len(test)},
    ])
    parameter_table = pd.DataFrame([
        {"parameter": key, "value": value, "role": "Pre-specified"}
        for key, value in model_parameters.items()
    ] + [{
        "parameter": "threshold", "value": threshold,
        "role": "Selected by Youden J on 2022",
    }])

    runtime_log.append({
        "stage": "reporting", "status": "OK",
        "elapsed_seconds": round(time.time() - started, 3),
        "detail": "3 basic comparison figures and metric tables generated",
    })
    tables = {
        "Run_Config": table_from_mapping(manifest),
        "Data_Splits": data_splits,
        "Model_Parameters": parameter_table,
        "Metrics_Comparison": metrics_comparison,
        "Metrics_Train": pd.DataFrame([metrics_train]),
        "Metrics_Validation_2023": pd.DataFrame([metrics_valid]),
        "Metrics_Test_2024": pd.DataFrame([metrics_test]),
        "Threshold_Metrics": threshold_curve,
        "Confusion_Matrix_Counts": confusion_counts,
        "Confusion_Matrix_Rates": confusion_rates,
        "Calibration_Bins": calibration,
        "Figure_Index": figure_index,
        "Runtime_Log": pd.DataFrame(runtime_log),
    }
    for name, frame in tables.items():
        write_table(OUT, name, frame)

    excel_ok = build_excel_workbook(OUT)
    verdict = None
    if args.smoke_test:
        verdict = write_smoke_report(OUT, excel_ok, time.time() - started)
    print("\nMetric comparison:")
    print(metrics_comparison.to_string(index=False))
    if verdict:
        print(f"\nSmoke-test verdict: {verdict}")
    print(f"\nResults saved to: {OUT}")
    print(f"Elapsed time: {time.time() - started:.1f} seconds")


if __name__ == "__main__":
    main()
