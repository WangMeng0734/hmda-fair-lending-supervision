# Logistic baseline

Run from this folder in the VSCode Base terminal.

## Formal full-sample run

```powershell
python run_logistic.py
```

Formal outputs are written only to `results` under this folder. If prior
Logistic results exist, the default prompt asks whether to overwrite or cancel.

## Complete smoke test

```powershell
python run_logistic.py --smoke-test --output-mode overwrite
```

The smoke test preserves the natural class distribution, uses at most 50,000
observations per year, and writes only to `smoke_test`.

## Output structure

- `models`: fitted Logistic model;
- `figures/png`, `figures/pdf`, `figures/svg`: ROC/PR, calibration, and threshold/confusion figures;
- `tables`: independent CSV result tables;
- `source_data`: figure source data and train/validation/test predictions;
- `logs`: workbook previews and QA artifacts;
- `model_results.xlsx`: consolidated metric workbook.

The baseline uses the same temporal evaluation design as the main model:
2018-2021 for threshold-model training, 2022 for threshold selection,
2018-2022 for the final refit, 2023 for external validation, and 2024 for the
untouched final test. Protected attributes are excluded from prediction.

This benchmark intentionally excludes SHAP, PDP/ALE, permutation importance,
coefficient interpretation, and protected-group audit. Those analyses belong to
the main LightGBM model; Logistic is retained only for performance comparison.
