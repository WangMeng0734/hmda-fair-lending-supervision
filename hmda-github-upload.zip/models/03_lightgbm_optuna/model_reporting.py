"""Reporting, explainability, and audit utilities for the unified HMDA model run.

This module is imported by run_lightgbm_optuna.py. It is not a separate entry point.
"""

from __future__ import annotations

import json
import math
import textwrap
import time
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Polygon
from scipy.stats import spearmanr
from sklearn.metrics import (
    accuracy_score, average_precision_score, balanced_accuracy_score,
    brier_score_loss, confusion_matrix, f1_score, log_loss,
    matthews_corrcoef, precision_recall_curve, precision_score, recall_score,
    roc_auc_score, roc_curve,
)
from statsmodels.nonparametric.smoothers_lowess import lowess


SEED = 20260731
NEG_COLOR = "#4F9D91"
NEUTRAL_COLOR = "#F3F1F4"
POS_COLOR = "#8572C4"
BLUE = NEG_COLOR
BLACK = "#111111"
GREY = "#7f7f7f"
CMAP = LinearSegmentedColormap.from_list(
    "shap_green_purple", [NEG_COLOR, NEUTRAL_COLOR, POS_COLOR]
)

mpl.rcParams.update({
    "font.family": "Times New Roman",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 11,
    "axes.labelsize": 11,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 11,
    "legend.title_fontsize": 11,
    "axes.linewidth": 0.8,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
    "figure.facecolor": "white",
    "axes.facecolor": "white",
})


def style_axis(ax):
    for side in ("top", "right", "bottom", "left"):
        ax.spines[side].set_visible(True)
        ax.spines[side].set_linewidth(0.8)
    ax.tick_params(direction="out", length=3.5, width=0.8, top=False, right=False)
    ax.grid(False)


def panel_label(ax, label):
    ax.text(0.02, 0.98, label, transform=ax.transAxes, fontsize=11,
            fontweight="bold", va="top", ha="left")


FEATURE_METADATA = {
    "x_state_code": ("STATE", "State code", "Identifier; no physical unit", "Categorical"),
    "x_county_code": ("COUNTY", "County code", "Identifier; no physical unit", "Categorical"),
    "x_msa_md": ("MSA_MD", "Metropolitan Statistical Area/Metropolitan Division code", "Identifier; no physical unit", "Categorical"),
    "x_preapproval": ("PREAPP", "Preapproval status", "Category; no physical unit", "Categorical"),
    "x_loan_type": ("LOAN_TYPE", "Loan type", "Category; no physical unit", "Categorical"),
    "x_loan_amount": ("LOAN_AMT", "Loan amount", "Million USD", "Continuous"),
    "x_ltv": ("LTV", "Loan-to-value ratio", "Percent", "Continuous"),
    "x_property_value": ("PROP_VAL", "Property value", "Million USD", "Continuous"),
    "x_income_thousands": ("INCOME", "Applicant income", "Thousand USD", "Continuous"),
    "x_dti_category": ("DTI", "Debt-to-income ratio category", "Category; no physical unit", "Categorical"),
    "x_tract_population": ("TR_POP", "Census tract population", "Persons", "Continuous"),
    "x_ffiec_msa_median_family_income": ("MSA_INC", "FFIEC MSA/MD median family income", "USD", "Continuous"),
    "x_tract_to_msa_income_pct": ("TR_MSA_INC", "Tract median family income relative to MSA/MD median", "Percent", "Continuous"),
    "x_tract_owner_occupied_units": ("OWNER_OCC", "Owner-occupied housing units in tract", "Housing units", "Continuous"),
    "x_tract_one_to_four_family_homes": ("FAM_HOMES", "One-to-four-family housing units in tract", "Housing units", "Continuous"),
    "x_tract_median_housing_age": ("HSG_AGE", "Median housing age in tract", "Years", "Continuous"),
    "x_ltv_missing": ("LTV_MISS", "Missing-value indicator for LTV", "Binary indicator; no physical unit", "Indicator"),
    "x_property_value_missing": ("PROP_MISS", "Missing-value indicator for property value", "Binary indicator; no physical unit", "Indicator"),
    "x_income_missing": ("INC_MISS", "Missing-value indicator for applicant income", "Binary indicator; no physical unit", "Indicator"),
    "x_dti_missing": ("DTI_MISS", "Missing-value indicator for DTI category", "Binary indicator; no physical unit", "Indicator"),
}


def feature_abbreviation(feature):
    """Return the single manuscript abbreviation used in every figure."""
    return FEATURE_METADATA.get(
        feature,
        (feature.removeprefix("x_").upper(), "", "", ""),
    )[0]


def display_feature_name(feature, wrap=None):
    label = feature_abbreviation(feature)
    return textwrap.fill(label, width=wrap) if wrap else label


def short_feature_name(feature):
    return feature_abbreviation(feature)


def feature_abbreviation_table(features):
    rows = []
    for feature in features:
        abbreviation, definition, unit, data_type = FEATURE_METADATA.get(
            feature,
            (feature.removeprefix("x_").upper(), feature, "Not specified", "Not specified"),
        )
        rows.append({
            "abbreviation": abbreviation,
            "model_variable": feature,
            "full_definition": definition,
            "figure_scale_or_unit": unit,
            "data_type": data_type,
        })
    return pd.DataFrame(rows)


def plotted_x(feature, values):
    """Return figure-scale values and the unit-free global abbreviation."""
    array = np.asarray(values, dtype=float)
    if feature == "x_property_value":
        return array / 1_000_000.0, feature_abbreviation(feature)
    if feature == "x_loan_amount":
        return array / 1_000_000.0, feature_abbreviation(feature)
    return array, feature_abbreviation(feature)


def save_figure(fig, out_dir, name):
    paths = []
    for fmt in ("png", "pdf", "svg"):
        directory = Path(out_dir) / "figures" / fmt
        directory.mkdir(parents=True, exist_ok=True)
        path = directory / f"{name}.{fmt}"
        kwargs = {"dpi": 600} if fmt == "png" else {}
        fig.savefig(path, **kwargs)
        paths.append(path)
    plt.close(fig)
    return paths


def safe_div(a, b):
    return float(a / b) if b else np.nan


def calibration_coefficients(y, p):
    y = np.asarray(y, dtype=float)
    p = np.clip(np.asarray(p, dtype=float), 1e-8, 1 - 1e-8)
    x = np.column_stack([np.ones(len(p)), np.log(p / (1 - p))])
    beta = np.array([0.0, 1.0])
    for _ in range(40):
        eta = np.clip(x @ beta, -30, 30)
        mu = 1 / (1 + np.exp(-eta))
        w = np.clip(mu * (1 - mu), 1e-8, None)
        hessian = x.T @ (w[:, None] * x)
        score = x.T @ (y - mu)
        try:
            step = np.linalg.solve(hessian, score)
        except np.linalg.LinAlgError:
            return np.nan, np.nan
        beta += step
        if np.max(np.abs(step)) < 1e-8:
            break
    return float(beta[0]), float(beta[1])


def classification_metrics(y, p, threshold, split=""):
    y = np.asarray(y, dtype=np.int8)
    p = np.clip(np.asarray(p, dtype=float), 1e-15, 1 - 1e-15)
    pred = (p >= threshold).astype(np.int8)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    intercept, slope = calibration_coefficients(y, p)
    return {
        "split": split,
        "N": int(len(y)),
        "prevalence": float(y.mean()),
        "roc_auc": float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else np.nan,
        "average_precision": float(average_precision_score(y, p)) if y.sum() else np.nan,
        "log_loss": float(log_loss(y, p, labels=[0, 1])),
        "brier_score": float(brier_score_loss(y, p)),
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "sensitivity": safe_div(tp, tp + fn),
        "specificity": safe_div(tn, tn + fp),
        "precision": safe_div(tp, tp + fp),
        "npv": safe_div(tn, tn + fn),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "matthews_correlation": float(matthews_corrcoef(y, pred)),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "threshold": float(threshold),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


def choose_youden_threshold(y, p):
    fpr, tpr, thresholds = roc_curve(y, p)
    finite = np.isfinite(thresholds)
    scores = np.where(finite, tpr - fpr, -np.inf)
    idx = int(np.argmax(scores))
    return float(thresholds[idx])


def bootstrap_cis(y, p, threshold, reps, seed, keys=None):
    if keys is None:
        keys = ["roc_auc", "average_precision", "brier_score", "sensitivity",
                "specificity", "precision", "f1"]
    y = np.asarray(y, dtype=np.int8)
    p = np.asarray(p, dtype=float)
    rng = np.random.default_rng(seed)
    values = {k: [] for k in keys}
    for _ in range(reps):
        idx = rng.integers(0, len(y), len(y))
        if len(np.unique(y[idx])) < 2:
            continue
        row = classification_metrics(y[idx], p[idx], threshold)
        for key in keys:
            if np.isfinite(row[key]):
                values[key].append(row[key])
    result = {}
    for key, vals in values.items():
        if vals:
            result[f"{key}_ci_low"] = float(np.percentile(vals, 2.5))
            result[f"{key}_ci_high"] = float(np.percentile(vals, 97.5))
        else:
            result[f"{key}_ci_low"] = np.nan
            result[f"{key}_ci_high"] = np.nan
    return result


def calibration_bins(y, p, split, bins=10):
    d = pd.DataFrame({"y": np.asarray(y), "p": np.asarray(p)})
    d["probability_bin"] = pd.qcut(d["p"], bins, labels=False, duplicates="drop") + 1
    out = d.groupby("probability_bin", observed=True).agg(
        N=("y", "size"), mean_predicted_probability=("p", "mean"),
        observed_denial_rate=("y", "mean"), p_min=("p", "min"), p_max=("p", "max")
    ).reset_index()
    out.insert(0, "split", split)
    return out


def threshold_metrics(y, p, thresholds=None):
    if thresholds is None:
        thresholds = np.linspace(0.01, 0.60, 100)
    rows = []
    for threshold in thresholds:
        m = classification_metrics(y, p, float(threshold))
        rows.append({k: m[k] for k in [
            "threshold", "sensitivity", "specificity", "precision", "f1",
            "accuracy", "balanced_accuracy", "npv",
        ]})
    return pd.DataFrame(rows)


def confusion_tables(y, p, threshold):
    pred = (np.asarray(p) >= threshold).astype(int)
    counts = confusion_matrix(y, pred, labels=[0, 1])
    rates = counts / counts.sum(axis=1, keepdims=True)
    labels = ["Actual approved", "Actual denied"]
    columns = ["Predicted approved", "Predicted denied"]
    counts_df = pd.DataFrame(counts, index=labels, columns=columns).reset_index(names="actual")
    rates_df = pd.DataFrame(rates, index=labels, columns=columns).reset_index(names="actual")
    return counts_df, rates_df


def numeric_values(series):
    if pd.api.types.is_categorical_dtype(series):
        return series.cat.codes.to_numpy(dtype=float)
    if pd.api.types.is_numeric_dtype(series):
        return series.to_numpy(dtype=float)
    return pd.Categorical(series.astype("string")).codes.astype(float)


def make_m1(study, out_dir):
    rows = []
    best = np.inf
    for trial in sorted(study.trials, key=lambda t: t.number):
        value = trial.value if trial.value is not None else np.nan
        if np.isfinite(value):
            best = min(best, value)
        row = {"trial": trial.number, "state": trial.state.name,
               "trial_fitness": value, "best_fitness": best}
        row.update({f"param_{k}": v for k, v in trial.params.items()})
        rows.append(row)
    source = pd.DataFrame(rows)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_M1.csv", index=False, encoding="utf-8-sig")
    completed = source[np.isfinite(source["trial_fitness"])].copy()
    params = ["learning_rate", "num_leaves", "min_child_samples", "feature_fraction", "lambda_l2"]
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, 7.2 / 2.54))
    ax = axes[0]
    ax.scatter(completed.trial, completed.trial_fitness, s=20, color=BLUE,
               alpha=0.75, label="Trial fitness")
    ax.step(completed.trial, completed.best_fitness, where="post", color=BLACK,
            lw=1.5, label="Best fitness")
    ax.set_xlabel("Trial"); ax.set_ylabel("Validation log loss"); ax.legend()
    ax.set_ylim(bottom=0.2275, top=0.23)
    style_axis(ax); panel_label(ax, "a")
    ax = axes[1]
    pdata = completed[[f"param_{p}" for p in params] + ["trial_fitness"]].astype(float)
    normed = (pdata - pdata.min()) / (pdata.max() - pdata.min()).replace(0, 1)
    color_norm = mpl.colors.Normalize(pdata.trial_fitness.min(), pdata.trial_fitness.max())
    x = np.arange(len(params) + 1)
    for i in range(len(pdata)):
        ax.plot(x, normed.iloc[i], color=CMAP(
            color_norm(pdata.trial_fitness.iloc[i])), lw=0.9, alpha=0.65)
    ax.set_xticks(x)
    ax.set_xticklabels(["Learn. rate", "Leaves", "Min. child", "Feat. frac.", "L2", "Objective"],
                       rotation=27, ha="right")
    ax.set_ylabel("Normalized value"); ax.set_ylim(-0.03, 1.03)
    sm = mpl.cm.ScalarMappable(norm=color_norm, cmap=CMAP)
    cbar = fig.colorbar(sm, ax=ax, pad=0.025, fraction=0.06)
    cbar.set_label("Validation log loss")
    style_axis(ax); panel_label(ax, "b")
    fig.subplots_adjust(left=0.11, right=0.93, bottom=0.30, top=0.97, wspace=0.42)
    return source, save_figure(fig, out_dir, "Figure_M1")


def make_m2(y_valid, p_valid, y_test, p_test, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, 7.2 / 2.54))
    frames = []
    for source_split, legend_label, y, p, color in [
        ("2023 validation", "Validation set", y_valid, p_valid, NEG_COLOR),
        ("2024 test", "Test set", y_test, p_test, POS_COLOR),
    ]:
        fpr, tpr, _ = roc_curve(y, p)
        precision, recall, _ = precision_recall_curve(y, p)
        auc = roc_auc_score(y, p); ap = average_precision_score(y, p)
        axes[0].plot(fpr, tpr, color=color, lw=1.5,
                     label=f"{legend_label} (AUC={auc:.4f})")
        axes[1].plot(recall, precision, color=color, lw=1.5,
                     label=f"{legend_label} (AP={ap:.4f})")
        frames.append(pd.DataFrame({"panel": "ROC", "split": source_split, "x": fpr, "y": tpr}))
        frames.append(pd.DataFrame({"panel": "PR", "split": source_split, "x": recall, "y": precision}))
        axes[1].axhline(np.mean(y), color=color, ls="--", lw=0.9, alpha=0.6)
    axes[0].plot([0, 1], [0, 1], ls="--", color=GREY, lw=0.8)
    axes[0].set(xlabel="False Positive Rate (FPR)", ylabel="True Positive Rate (TPR)")
    axes[1].set(xlabel="Recall", ylabel="Precision")
    for label, ax in zip(("a", "b"), axes):
        ax.legend(loc="best"); style_axis(ax); panel_label(ax, label)
    fig.subplots_adjust(left=0.09, right=0.98, bottom=0.20, top=0.95, wspace=0.35)
    source = pd.concat(frames, ignore_index=True)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_M2.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_M2")


def make_m3(calibration, y_test, p_test, threshold, metrics_valid, metrics_test, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, 7.2 / 2.54))
    ax = axes[0]
    for split, legend_label, color, metrics in [
        ("2023 validation", "Validation set", NEG_COLOR, metrics_valid),
        ("2024 test", "Test set", POS_COLOR, metrics_test),
    ]:
        d = calibration[calibration.split == split]
        ax.plot(d.mean_predicted_probability, d.observed_denial_rate, marker="o",
                ms=3.5, lw=1.3, color=color,
                label=(f"{'Val.' if 'Validation' in legend_label else 'Test'}: "
                       f"{metrics['brier_score']:.4f} / "
                       f"{metrics['calibration_slope']:.4f} / "
                       f"{metrics['calibration_intercept']:.4f}"))
    ax.plot([0, 1], [0, 1], ls="--", color=GREY, lw=0.9)
    ax.set(xlabel="Mean predicted probability", ylabel="Observed denial rate")
    legend = ax.legend(
        fontsize=7.5, loc="upper right", title="Brier / slope / intercept",
        title_fontsize=7.5, handlelength=1.1, labelspacing=0.25,
        borderpad=0.35, framealpha=0.94,
    )
    legend.get_frame().set_facecolor("white")
    style_axis(ax); panel_label(ax, "a")
    ax = axes[1]
    bins = np.linspace(0, max(0.6, np.quantile(p_test, 0.995)), 35)
    ax.hist(p_test[np.asarray(y_test) == 0], bins=bins, density=True, histtype="step",
            color=NEG_COLOR, lw=1.5, label="Approved applications")
    ax.hist(p_test[np.asarray(y_test) == 1], bins=bins, density=True, histtype="step",
            color=POS_COLOR, lw=1.5, label="Denied applications")
    ax.axvline(threshold, color=BLACK, ls="--", lw=1.1, label=f"Threshold={threshold:.4f}")
    ax.set(xlabel="Predicted denial probability", ylabel="Density")
    ax.legend(fontsize=11); style_axis(ax); panel_label(ax, "b")
    fig.subplots_adjust(left=0.10, right=0.98, bottom=0.20, top=0.96, wspace=0.38)
    distribution = pd.DataFrame({"y_denied": y_test, "predicted_probability": p_test})
    source = pd.concat([
        calibration.assign(source_type="calibration"),
        distribution.assign(source_type="distribution"),
    ], ignore_index=True, sort=False)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_M3.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_M3")


def make_m4(counts, rates, threshold_curve, threshold, out_dir):
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, 7.2 / 2.54))
    matrix = rates[["Predicted approved", "Predicted denied"]].to_numpy()
    ax = axes[0]
    image = ax.imshow(matrix, vmin=0, vmax=1, cmap=CMAP)
    for i in range(2):
        for j in range(2):
            ax.text(j, i, f"{matrix[i, j]:.4%}", ha="center", va="center", fontsize=11)
    ax.set_xticks([0, 1], ["Pred. approved", "Pred. denied"], rotation=20, ha="right")
    ax.set_yticks([0, 1], ["Actual approved", "Actual denied"])
    fig.colorbar(image, ax=ax, fraction=0.05, pad=0.03)
    style_axis(ax); panel_label(ax, "a")
    ax = axes[1]
    for metric, color in [("sensitivity", POS_COLOR), ("specificity", NEG_COLOR),
                          ("precision", "#A99BDA"), ("f1", "#78B5AA")]:
        ax.plot(threshold_curve.threshold, threshold_curve[metric], lw=1.2,
                color=color, label=metric.capitalize())
    ax.axvline(threshold, color=BLACK, ls="--", lw=1.1, label=f"Threshold={threshold:.4f}")
    ax.set(xlabel="Decision threshold", ylabel="Metric value", ylim=(0, 1.02))
    ax.legend(fontsize=11); style_axis(ax); panel_label(ax, "b")
    fig.subplots_adjust(left=0.16, right=0.98, bottom=0.25, top=0.96, wspace=0.43)
    source = pd.concat([
        counts.assign(source_type="counts"), rates.assign(source_type="rates"),
        threshold_curve.assign(source_type="threshold_curve"),
    ], ignore_index=True, sort=False)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_M4.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_M4")


def state_year_metrics(valid, p_valid, test, p_test, threshold, bootstrap_reps):
    rows = []
    for split, frame, probs in [("2023", valid, p_valid), ("2024", test, p_test)]:
        groups = [("All", np.ones(len(frame), dtype=bool))]
        states = frame["x_state_code"].astype("string")
        groups += [
            (state, (states == state).fillna(False).to_numpy(dtype=bool))
            for state in ["CA", "NY", "TX"]
        ]
        for state, mask in groups:
            y = frame.loc[mask, "y_denied"].to_numpy(); p = np.asarray(probs)[mask]
            row = classification_metrics(y, p, threshold, split)
            row["state"] = state
            row.update(bootstrap_cis(y, p, threshold, bootstrap_reps,
                                     SEED + len(rows), ["roc_auc", "average_precision",
                                     "brier_score", "sensitivity", "specificity"]))
            rows.append(row)
    return pd.DataFrame(rows)


def make_m5(stability, out_dir):
    metrics = ["roc_auc", "average_precision", "brier_score", "sensitivity", "specificity"]
    fig, axes = plt.subplots(1, 5, figsize=(17 / 2.54, 7.5 / 2.54), sharey=True)
    labels = stability["split"] + " " + stability["state"]
    y_pos = np.arange(len(stability))[::-1]
    colors = [NEG_COLOR if s == "2023" else POS_COLOR for s in stability.split]
    for ax, metric in zip(axes, metrics):
        x = stability[metric].to_numpy()
        lo = stability[f"{metric}_ci_low"].to_numpy()
        hi = stability[f"{metric}_ci_high"].to_numpy()
        ax.errorbar(x, y_pos, xerr=[x - lo, hi - x], fmt="none", ecolor=GREY,
                    elinewidth=0.8, capsize=2)
        ax.scatter(x, y_pos, c=colors, s=18, zorder=3)
        ax.set_xlabel(metric.replace("_", "\n"))
        ax.set_yticks(y_pos)
        if ax is axes[0]:
            ax.set_yticklabels(labels)
        else:
            ax.tick_params(labelleft=False)
        style_axis(ax)
    fig.subplots_adjust(left=0.18, right=0.99, bottom=0.27, top=0.97, wspace=0.28)
    stability.to_csv(Path(out_dir) / "source_data" / "Figure_M5.csv", index=False, encoding="utf-8-sig")
    return stability, save_figure(fig, out_dir, "Figure_M5")


def load_group_audit(audit_path, test_ids):
    cols = ["application_row_id", "x_activity_year", "a_derived_race",
            "a_derived_ethnicity", "a_derived_sex", "a_applicant_age"]
    audit = pd.read_parquet(audit_path, columns=cols, filters=[("x_activity_year", "==", 2024)])
    return pd.DataFrame({"application_row_id": test_ids}).merge(
        audit.drop(columns="x_activity_year"), on="application_row_id", how="left", validate="one_to_one"
    )


def group_audit_table(audit, y, p, threshold, bootstrap_reps):
    mappings = {
        "Race": "a_derived_race", "Ethnicity": "a_derived_ethnicity",
        "Sex": "a_derived_sex", "Age": "a_applicant_age",
    }
    rows = []
    y = np.asarray(y); p = np.asarray(p); pred = (p >= threshold).astype(int)
    for dimension, column in mappings.items():
        groups = audit[column].astype("string").fillna("Missing")
        for group in sorted(groups.unique()):
            mask = (groups == group).fillna(False).to_numpy(dtype=bool)
            yg, pg, predg = y[mask], p[mask], pred[mask]
            tn, fp, fn, tp = confusion_matrix(yg, predg, labels=[0, 1]).ravel()
            row = {
                "dimension": dimension, "group": str(group), "N": int(mask.sum()),
                "denial_rate": float(yg.mean()), "predicted_positive_rate": float(predg.mean()),
                "sensitivity": safe_div(tp, tp + fn), "specificity": safe_div(tn, tn + fp),
                "false_positive_rate": safe_div(fp, fp + tn),
                "false_negative_rate": safe_div(fn, fn + tp),
                "precision": safe_div(tp, tp + fp), "brier_score": float(brier_score_loss(yg, pg)),
                "threshold": threshold,
            }
            if len(np.unique(yg)) == 2 and len(yg) >= 20:
                row.update(bootstrap_cis(yg, pg, threshold, bootstrap_reps,
                                         SEED + len(rows), ["sensitivity", "specificity"]))
            rows.append(row)
    return pd.DataFrame(rows)


def make_m6(groups, out_dir):
    plot = groups[groups.N >= 20].copy().reset_index(drop=True)
    labels = (plot.dimension + ": " + plot.group).map(
        lambda value: textwrap.fill(value, width=29)
    )
    y_pos = np.arange(len(plot))[::-1]
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, max(14, len(plot) * 0.90) / 2.54), sharey=True)
    for ax, metric in zip(axes, ["sensitivity", "specificity"]):
        x = plot[metric].to_numpy()
        lo = plot.get(f"{metric}_ci_low", pd.Series(np.nan, index=plot.index)).to_numpy()
        hi = plot.get(f"{metric}_ci_high", pd.Series(np.nan, index=plot.index)).to_numpy()
        valid = np.isfinite(lo) & np.isfinite(hi)
        ax.errorbar(x[valid], y_pos[valid], xerr=[x[valid] - lo[valid], hi[valid] - x[valid]],
                    fmt="none", ecolor=GREY, elinewidth=0.8, capsize=2)
        ax.scatter(x, y_pos, color=POS_COLOR if metric == "sensitivity" else NEG_COLOR, s=18)
        ax.set_xlabel(metric.capitalize()); ax.set_xlim(0, 1)
        ax.set_yticks(y_pos)
        if ax is axes[0]:
            ax.set_yticklabels(labels)
        else:
            ax.tick_params(labelleft=False)
        style_axis(ax)
    fig.text(0.5, 0.018,
             "Descriptive model audit; disparities do not by themselves establish\n"
             "discrimination or causal effects.",
             ha="center", fontsize=11)
    fig.subplots_adjust(left=0.32, right=0.98, bottom=0.20, top=0.98, wspace=0.28)
    groups.to_csv(Path(out_dir) / "source_data" / "Figure_M6.csv", index=False, encoding="utf-8-sig")
    return groups, save_figure(fig, out_dir, "Figure_M6")


def shap_analysis(model, test, p_test, features, categorical, threshold, out_dir, smoke):
    sample_n = min(len(test), 2000 if smoke else 30000)
    sample = test.sample(sample_n, random_state=SEED).copy()
    sample_pos = test.index.get_indexer(sample.index)
    sample_p = np.asarray(p_test)[sample_pos]
    matrix = model.predict(sample[features], pred_contrib=True)
    shap_values = np.asarray(matrix[:, :-1], dtype=float)
    base_values = np.asarray(matrix[:, -1], dtype=float)
    index_table = sample[["application_row_id", "y_denied"]].copy()
    index_table["predicted_probability"] = sample_p
    index_table["random_seed"] = SEED
    index_table["sample_rule"] = "Natural random sample from 2024 test set"
    global_imp = pd.DataFrame({
        "feature": features, "mean_abs_shap": np.abs(shap_values).mean(axis=0),
        "mean_shap": shap_values.mean(axis=0),
    }).sort_values("mean_abs_shap", ascending=False)
    top10 = global_imp.head(10).feature.tolist()
    feature_index = {f: i for i, f in enumerate(features)}
    numeric_matrix = np.column_stack([numeric_values(sample[f]) for f in features])
    return sample, sample_p, shap_values, base_values, index_table, global_imp, top10, feature_index, numeric_matrix


def make_x1(sample, shap_values, global_imp, top10, feature_index, numeric_matrix, out_dir):
    """Unified class-wise binary SHAP display in one contiguous figure."""
    order = top10[::-1]
    display = [display_feature_name(f) for f in order]
    limit = float(np.nanpercentile(np.abs(shap_values[:, [feature_index[f] for f in top10]]), 99))
    importance = {
        feature: float(np.mean(np.abs(shap_values[:, feature_index[feature]])))
        for feature in order
    }
    fig, axes = plt.subplots(
        1, 2, figsize=(17 / 2.54, 12 / 2.54), sharey=True,
        gridspec_kw={"wspace": 0.02},
    )
    rows = []
    for ax, class_value, multiplier, label, bar_color in [
        (axes[0], 0, -1.0, "Class 0", NEG_COLOR),
        (axes[1], 1, 1.0, "Class 1", POS_COLOR),
    ]:
        for yi, feature in enumerate(order):
            j = feature_index[feature]
            values = numeric_matrix[:, j]
            class_shap = multiplier * shap_values[:, j]
            mean_abs = float(np.mean(np.abs(class_shap)))
            lo, hi = np.nanpercentile(values, [1, 99])
            norm = mpl.colors.Normalize(lo, hi if hi > lo else lo + 1)
            rng = np.random.default_rng(SEED + yi + class_value * 100)
            ax.scatter(class_shap, yi + rng.normal(0, 0.09, len(values)), c=values,
                       cmap=CMAP, norm=norm, s=4, alpha=0.40, rasterized=True)
            rows.append(pd.DataFrame({
                "class": class_value, "class_label": label, "feature": feature,
                "shap_value": class_shap, "feature_value": values,
                "mean_abs_shap": mean_abs,
                "importance_stack_start": 0.0 if class_value == 0 else importance[feature],
                "importance_stack_end": (importance[feature] if class_value == 0
                                         else 2.0 * importance[feature]),
                "definition": "Derived as -Class 1 SHAP" if class_value == 0 else "Native denial-output SHAP",
            }))
        ax.axvline(0, color=GREY, ls="--", lw=0.8)
        ax.set_xlim(-limit, limit)
        ax.set_yticks(range(len(order)))
        if ax is axes[0]:
            ax.set_yticklabels(display)
        else:
            ax.tick_params(labelleft=False, left=False)
        style_axis(ax)
    # Visually join the two class-specific SHAP halves into a single frame.
    axes[0].spines["right"].set_visible(False)
    axes[1].spines["left"].set_visible(False)
    axes[0].text(0.5, -0.13, "Class 0",
                 transform=axes[0].transAxes, ha="center", va="top", color=NEG_COLOR)
    axes[1].text(0.5, -0.13, "Class 1",
                 transform=axes[1].transAxes, ha="center", va="top", color=POS_COLOR)
    sm = mpl.cm.ScalarMappable(cmap=CMAP, norm=mpl.colors.Normalize(0, 1))
    cax = fig.add_axes([0.925, 0.23, 0.016, 0.58])
    cbar = fig.colorbar(sm, cax=cax, ticks=[0, 1])
    cbar.ax.set_yticklabels(["Low", "High"]); cbar.set_label("Feature value")
    fig.text(0.55, 0.055, "SHAP value", ha="center", va="center")
    fig.subplots_adjust(left=0.22, right=0.90, bottom=0.22, top=0.88, wspace=0.02)

    # One cumulative importance scale spans the full composite. Class 0 starts
    # at the common left origin and Class 1 is stacked from the Class 0 endpoint.
    left_pos = axes[0].get_position()
    right_pos = axes[1].get_position()
    bar_ax = fig.add_axes([
        left_pos.x0, left_pos.y0,
        right_pos.x1 - left_pos.x0, left_pos.height,
    ], label="x1_cumulative_importance")
    class0_importance = np.array([importance[f] for f in order], dtype=float)
    class1_importance = np.array([importance[f] for f in order], dtype=float)
    bar_ax.barh(
        range(len(order)), class0_importance, height=0.72,
        color=NEG_COLOR, alpha=0.20, edgecolor="none",
    )
    bar_ax.barh(
        range(len(order)), class1_importance, left=class0_importance,
        height=0.72, color=POS_COLOR, alpha=0.20, edgecolor="none",
    )
    bar_ax.set_xlim(0, float(np.max(class0_importance + class1_importance)) * 1.05)
    bar_ax.set_ylim(axes[0].get_ylim())
    bar_ax.set_xlabel("Importance value", labelpad=4)
    bar_ax.xaxis.set_label_position("top")
    bar_ax.xaxis.tick_top()
    bar_ax.xaxis.set_major_locator(mpl.ticker.MaxNLocator(nbins=4, min_n_ticks=3))
    bar_ax.tick_params(axis="x", top=True, labeltop=True, bottom=False,
                       labelbottom=False, length=3.5, width=0.8)
    bar_ax.tick_params(axis="y", left=False, right=False,
                       labelleft=False, labelright=False)
    for side in ("left", "right", "bottom"):
        bar_ax.spines[side].set_visible(False)
    bar_ax.spines["top"].set_visible(True)
    bar_ax.spines["top"].set_linewidth(0.8)
    bar_ax.set_facecolor("none")
    bar_ax.set_zorder(0)
    for ax in axes:
        ax.set_zorder(2)
        ax.patch.set_alpha(0)
    source = pd.concat(rows, ignore_index=True)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_X1.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_X1")


def dependence_payload(sample, shap_values, global_imp, feature_index, features, categorical):
    candidates = [f for f in global_imp.feature if f not in categorical and
                  pd.api.types.is_numeric_dtype(sample[f])][:6]
    numeric_features = [f for f in features if f not in categorical]
    rows = []
    payload = []
    for feature in candidates:
        j = feature_index[feature]
        x = numeric_values(sample[feature]); y = shap_values[:, j]
        mask = np.isfinite(x) & np.isfinite(y)
        lo, hi = np.nanpercentile(x[mask], [1, 99]); mask &= (x >= lo) & (x <= hi)
        interaction = None; best_corr = -1
        for other in numeric_features:
            if other == feature: continue
            vals = numeric_values(sample[other])
            valid = mask & np.isfinite(vals)
            if valid.sum() < 20 or np.unique(vals[valid]).size < 2 or np.unique(y[valid]).size < 2:
                continue
            corr = abs(spearmanr(vals[valid], y[valid], nan_policy="omit").correlation)
            if np.isfinite(corr) and corr > best_corr:
                best_corr, interaction = corr, other
        color = numeric_values(sample[interaction]) if interaction else np.zeros(len(sample))
        smooth = lowess(y[mask], x[mask], frac=0.25, return_sorted=True)
        payload.append((feature, x, y, color, mask, interaction, smooth))
        rows.append(pd.DataFrame({
            "feature": feature, "feature_value": x[mask], "shap_value": y[mask],
            "interaction_feature": interaction, "interaction_value": color[mask],
            "method": "LOWESS frac=0.25; 1st-99th percentile display",
        }))
    return payload, (pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()), candidates


def make_x2(sample, shap_values, global_imp, top10, feature_index, numeric_matrix,
            features, categorical, out_dir):
    """Positive-class global SHAP and six dependence panels in one composite figure."""
    payload, dependence, candidates = dependence_payload(
        sample, shap_values, global_imp, feature_index, features, categorical
    )
    fig = plt.figure(figsize=(17 / 2.54, 18 / 2.54))
    ax = fig.add_axes([0.20, 0.07, 0.30, 0.86])
    order = top10[::-1]
    display = [display_feature_name(f) for f in order]
    global_rows = []
    for yi, feature in enumerate(order):
        j = feature_index[feature]
        vals = shap_values[:, j]; feature_values = numeric_matrix[:, j]
        mean_abs = float(np.mean(np.abs(vals)))
        ax.barh(yi, mean_abs, height=0.72, color=POS_COLOR, alpha=0.16)
        lo, hi = np.nanpercentile(feature_values, [1, 99])
        rng = np.random.default_rng(SEED + yi)
        ax.scatter(vals, yi + rng.normal(0, 0.09, len(vals)), c=feature_values,
                   cmap=CMAP, norm=mpl.colors.Normalize(lo, hi if hi > lo else lo + 1),
                   s=4, alpha=0.38, rasterized=True)
        global_rows.append(pd.DataFrame({
            "source_type": "positive_class_global", "feature": feature,
            "shap_value": vals, "feature_value": feature_values,
            "mean_abs_shap": mean_abs,
        }))
    ax.axvline(0, color=GREY, ls="--", lw=0.8)
    ax.set_yticks(range(len(order)), display)
    ax.set_xlabel("SHAP value")
    style_axis(ax); panel_label(ax, "a")
    global_cax = fig.add_axes([0.515, 0.07, 0.012, 0.86])
    global_sm = mpl.cm.ScalarMappable(cmap=CMAP, norm=mpl.colors.Normalize(0, 1))
    global_cbar = fig.colorbar(global_sm, cax=global_cax, ticks=[0, 1])
    global_cbar.ax.set_yticklabels(["Low", "High"])
    global_cbar.ax.set_title("Feature\nvalue", pad=3)
    dep_axes = []
    row_bottoms = [0.74, 0.405, 0.07]
    plot_lefts = [0.61, 0.81]
    cbar_lefts = [0.748, 0.948]
    for k, (feature, x, y, color, mask, interaction, smooth) in enumerate(payload):
        row = k // 2
        column = k % 2
        dep_ax = fig.add_axes([plot_lefts[column], row_bottoms[row], 0.13, 0.19])
        dep_axes.append(dep_ax)
        valid_color = color[mask]
        clo, chi = np.nanpercentile(valid_color, [1, 99]) if np.isfinite(valid_color).any() else (0, 1)
        color_span = chi - clo if chi > clo else 1.0
        scaled_color = np.clip((valid_color - clo) / color_span, 0, 1)
        x_plot, x_label = plotted_x(feature, x[mask])
        smooth_x, _ = plotted_x(feature, smooth[:, 0])
        scatter = dep_ax.scatter(
            x_plot, y[mask], c=scaled_color, cmap=CMAP,
            norm=mpl.colors.Normalize(0, 1), s=5, alpha=0.35,
            rasterized=True,
        )
        dep_ax.plot(smooth_x, smooth[:, 1], color=BLACK, lw=1.2)
        dep_ax.axhline(0, color=GREY, ls="--", lw=0.8)
        dep_ax.set_xlabel(textwrap.fill(x_label, width=15), fontsize=10)
        dep_ax.tick_params(axis="both", labelsize=10)
        if k % 2 == 0:
            dep_ax.set_ylabel("SHAP value", fontsize=10)
            # Manual axes do not participate reliably in fig.align_ylabels();
            # a fixed coordinate keeps panels b, d, and f exactly aligned.
            dep_ax.yaxis.set_label_coords(-0.40, 0.5)
        else:
            dep_ax.set_ylabel("")
            dep_ax.tick_params(labelleft=False)
        style_axis(dep_ax); panel_label(dep_ax, chr(ord("b") + k))
        dep_cax = fig.add_axes([cbar_lefts[column], row_bottoms[row], 0.008, 0.19])
        dep_cbar = fig.colorbar(scatter, cax=dep_cax, ticks=[0, 1])
        dep_cbar.ax.set_yticklabels(["0", "1"])
        dep_cbar.ax.tick_params(labelsize=10)
        dep_cbar.ax.set_title(
            feature_abbreviation(interaction).replace("_", "\n") if interaction else "INT",
            pad=3, fontsize=10,
        )
    source = pd.concat(global_rows + [dependence.assign(source_type="dependence")],
                       ignore_index=True, sort=False)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_X2.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_X2"), dependence, candidates


def make_x3(shap_values, global_imp, feature_index, out_dir):
    """Standalone positive-class SHAP importance subfigure with distribution ridges."""
    top = global_imp.head(12).copy().iloc[::-1].reset_index(drop=True)
    total = float(global_imp.mean_abs_shap.sum())
    top["importance_share_pct"] = 100 * top.mean_abs_shap / total if total else 0
    y_pos = np.arange(len(top))
    fig, ax = plt.subplots(figsize=(17 / 2.54, 10.5 / 2.54))
    ax.barh(y_pos, top.mean_abs_shap, color=POS_COLOR, alpha=0.32, height=0.70)
    rows = []
    for yi, row in top.iterrows():
        vals = np.abs(shap_values[:, feature_index[row.feature]])
        upper = np.nanpercentile(vals, 99)
        hist, edges = np.histogram(vals[np.isfinite(vals)], bins=28, range=(0, upper), density=True)
        centers = (edges[:-1] + edges[1:]) / 2
        scaled = hist / hist.max() * 0.28 if hist.max() else hist
        ridge_x = centers / upper * float(row.mean_abs_shap) if upper > 0 else centers
        ax.plot(ridge_x, yi + scaled, color=BLACK, lw=0.7)
        rows.append({
            "feature": row.feature, "mean_abs_shap": row.mean_abs_shap,
            "importance_share_pct": row.importance_share_pct,
            "abs_shap_p25": np.nanpercentile(vals, 25),
            "abs_shap_median": np.nanpercentile(vals, 50),
            "abs_shap_p75": np.nanpercentile(vals, 75),
        })
    ax.set_yticks(y_pos, [short_feature_name(f) for f in top.feature])
    ax.set_xlabel("Mean(|SHAP value|)")
    style_axis(ax)
    ax.set_xlim(0, max(1e-6, float(top.mean_abs_shap.max()) * 1.12))
    inset = ax.inset_axes([0.50, 0.03, 0.47, 0.40])
    shares = global_imp.head(6).mean_abs_shap.to_numpy()
    inset.pie(shares, colors=[POS_COLOR, "#A99BDA", "#C9C0E8", NEUTRAL_COLOR,
                              "#A8CEC6", NEG_COLOR], startangle=90,
              wedgeprops={"width": 0.42, "edgecolor": "white"},
              autopct=lambda p: f"{p:.0f}%" if p >= 15 else "",
              textprops={"fontsize": 11})
    inset.set_aspect("equal")
    source = pd.DataFrame(rows)
    source.to_csv(Path(out_dir) / "source_data" / "Figure_X3.csv", index=False, encoding="utf-8-sig")
    fig.subplots_adjust(left=0.16, right=0.98, bottom=0.13, top=0.98)
    return source, save_figure(fig, out_dir, "Figure_X3")


def make_x4(sample, sample_p, shap_values, top10, feature_index, out_dir, smoke):
    n = min(len(sample), 100 if smoke else 400)
    idx = np.argsort(sample_p)[-n:]
    selected_p = sample_p[idx]
    top = top10[:9]
    values = np.column_stack([shap_values[idx, feature_index[f]] for f in top])
    other = shap_values[idx].sum(axis=1) - values.sum(axis=1)
    matrix = np.column_stack([values, other]).T
    names = [short_feature_name(f) for f in top] + ["OTHER"]
    limit = np.nanpercentile(np.abs(matrix), 99)
    # Standalone heatmap: fixed 17 cm double-column width.
    fig = plt.figure(figsize=(17 / 2.54, 9.5 / 2.54))
    gs = fig.add_gridspec(2, 1, height_ratios=[1, 4], hspace=0.05)
    ax_top = fig.add_subplot(gs[0]); ax = fig.add_subplot(gs[1], sharex=ax_top)
    ax_top.plot(np.arange(n), selected_p, color=BLACK, lw=1.0)
    ax_top.set_ylabel("Predicted\nprobability"); ax_top.tick_params(labelbottom=False)
    style_axis(ax_top)
    im = ax.imshow(matrix, aspect="auto", cmap=CMAP, norm=TwoSlopeNorm(vcenter=0, vmin=-limit, vmax=limit))
    ax.set_yticks(range(len(names)), names)
    ax.set_xlabel("Applications ordered by\npredicted denial probability")
    style_axis(ax)
    fig.colorbar(im, ax=ax, fraction=0.06, pad=0.025).set_label("SHAP value")
    fig.subplots_adjust(left=0.18, right=0.93, bottom=0.20, top=0.97)
    source = pd.DataFrame(matrix.T, columns=top + ["Sum of other features"])
    source.insert(0, "predicted_probability", selected_p)
    source.insert(0, "application_row_id", sample.iloc[idx].application_row_id.to_numpy())
    source.to_csv(Path(out_dir) / "source_data" / "Figure_X4.csv", index=False, encoding="utf-8-sig")
    return source, save_figure(fig, out_dir, "Figure_X4")


def make_x5(sample, sample_p, shap_values, base_values, top10, feature_index, threshold, out_dir):
    # Remove the legacy all-in-one X5 artifact so resume-mode runs do not leave
    # an obsolete figure beside the four current independently exported panels.
    for fmt in ("png", "pdf", "svg"):
        legacy_path = Path(out_dir) / "figures" / fmt / f"Figure_X5.{fmt}"
        if legacy_path.exists():
            legacy_path.unlink()

    y = sample.y_denied.to_numpy(); pred = (sample_p >= threshold).astype(int)
    definitions = [(0, 0, "True negative", "TN"), (1, 1, "True positive", "TP"),
                   (0, 1, "False positive", "FP"), (1, 0, "False negative", "FN")]
    selected = []
    for actual, predicted, label, code in definitions:
        candidates = np.where((y == actual) & (pred == predicted))[0]
        if len(candidates) == 0:
            selected.append((label, code, None)); continue
        median = np.median(sample_p[candidates])
        chosen = candidates[np.argmin(np.abs(sample_p[candidates] - median))]
        selected.append((label, code, int(chosen)))
    rows = []
    paths = []
    for label, code, idx in selected:
        fig, ax = plt.subplots(figsize=(17 / 2.54, 9 / 2.54))
        if idx is None:
            ax.text(0.5, 0.5, "No case available", ha="center", va="center")
            style_axis(ax)
            case_frame = pd.DataFrame([{"case_type": label, "case_code": code,
                                        "status": "No case available"}])
            case_frame.to_csv(Path(out_dir) / "source_data" / f"Figure_X5_{code}.csv",
                              index=False, encoding="utf-8-sig")
            paths += save_figure(fig, out_dir, f"Figure_X5_{code}")
            rows.extend(case_frame.to_dict("records"))
            continue
        all_contributions = pd.Series(
            shap_values[idx], index=list(feature_index.keys()), dtype=float
        )
        contributions = all_contributions.reindex(
            all_contributions.abs().sort_values(ascending=False).index
        ).head(8)
        contributions.loc["Sum of other features"] = (
            all_contributions.sum() - contributions.sum()
        )
        starts = [float(base_values[idx])]
        for value in contributions.iloc[:-1]:
            starts.append(starts[-1] + float(value))
        starts = np.asarray(starts)
        ends = starts + contributions.to_numpy(dtype=float)
        y_positions = np.arange(len(contributions))[::-1]
        case_rows = []
        x_span = max(1e-6, float(max(np.max(ends), np.max(starts)) - min(np.min(ends), np.min(starts))))
        for ypos, feature, value, start_value, end_value in zip(
            y_positions, contributions.index, contributions, starts, ends
        ):
            half_height = 0.34
            tip = min(abs(float(value)) * 0.18, x_span * 0.025)
            if value >= 0:
                vertices = [(start_value, ypos - half_height),
                            (end_value - tip, ypos - half_height),
                            (end_value, ypos),
                            (end_value - tip, ypos + half_height),
                            (start_value, ypos + half_height)]
            else:
                vertices = [(start_value, ypos - half_height),
                            (end_value + tip, ypos - half_height),
                            (end_value, ypos),
                            (end_value + tip, ypos + half_height),
                            (start_value, ypos + half_height)]
            ax.add_patch(Polygon(vertices, closed=True,
                                 facecolor=POS_COLOR if value >= 0 else NEG_COLOR,
                                 edgecolor="white", linewidth=0.5))
            feature_value = sample.iloc[idx][feature] if feature != "Sum of other features" else np.nan
            record = {
                "case_type": label,
                "case_code": code,
                "application_row_id": sample.iloc[idx].application_row_id,
                "actual_label": int(y[idx]), "predicted_class": int(pred[idx]),
                "predicted_probability": float(sample_p[idx]),
                "base_value_log_odds": float(base_values[idx]),
                "feature": feature, "feature_value": str(feature_value),
                "shap_value": float(value),
                "step_start_log_odds": float(start_value),
                "step_end_log_odds": float(end_value),
                "selection_rule": "Probability closest to within-case-type median",
            }
            rows.append(record); case_rows.append(record)
        final_log_odds = float(base_values[idx] + all_contributions.sum())
        ax.axvline(base_values[idx], color=GREY, ls="--", lw=0.8, label="Base")
        ax.axvline(final_log_odds, color=BLACK, ls=":", lw=0.9, label="Final")
        ax.set_yticks(
            y_positions,
            [short_feature_name(f) if f != "Sum of other features" else
             "OTHER" for f in contributions.index],
        )
        ax.set_ylim(-0.6, len(contributions) - 0.4)
        ax.set_xlabel("Model output"); style_axis(ax)
        legend_location = {"TN": "lower right", "TP": "upper right",
                           "FP": "upper right", "FN": "lower left"}[code]
        legend = ax.legend(
            title=f"{label}; p={sample_p[idx]:.4f}", fontsize=8.5,
            loc=legend_location, ncol=2, borderaxespad=0.35,
            handlelength=1.15, labelspacing=0.25, columnspacing=0.8,
            borderpad=0.35, framealpha=0.94,
            title_fontsize=9,
        )
        legend.get_frame().set_facecolor("white")
        # Each case is an independent 17 cm double-column figure.
        fig.set_size_inches(17 / 2.54, 9 / 2.54)
        fig.subplots_adjust(left=0.20, right=0.97, bottom=0.16, top=0.86)
        pd.DataFrame(case_rows).to_csv(
            Path(out_dir) / "source_data" / f"Figure_X5_{code}.csv",
            index=False, encoding="utf-8-sig"
        )
        paths += save_figure(fig, out_dir, f"Figure_X5_{code}")
    cases = pd.DataFrame(rows)
    cases.to_csv(Path(out_dir) / "source_data" / "Figure_X5.csv", index=False, encoding="utf-8-sig")
    return cases, paths


def permutation_importance(model, test, p_test, features, repeats, sample_n):
    sample = test.sample(min(sample_n, len(test)), random_state=SEED).copy()
    positions = test.index.get_indexer(sample.index)
    y = sample.y_denied.to_numpy(); base_p = np.asarray(p_test)[positions]
    base_auc = roc_auc_score(y, base_p); base_loss = log_loss(y, base_p, labels=[0, 1])
    rng = np.random.default_rng(SEED)
    rows = []
    for feature in features:
        auc_drops, loss_increases = [], []
        original = sample[feature].copy()
        for _ in range(repeats):
            permuted = sample.copy()
            order = rng.permutation(len(sample))
            if pd.api.types.is_categorical_dtype(original):
                permuted[feature] = pd.Categorical(
                    original.iloc[order].astype("string"),
                    categories=original.cat.categories,
                )
            else:
                permuted[feature] = original.iloc[order].to_numpy()
            pp = model.predict(permuted[features])
            auc_drops.append(base_auc - roc_auc_score(y, pp))
            loss_increases.append(log_loss(y, pp, labels=[0, 1]) - base_loss)
        rows.append({"feature": feature, "auc_drop_mean": np.mean(auc_drops),
                     "auc_drop_sd": np.std(auc_drops, ddof=1) if repeats > 1 else 0,
                     "logloss_increase_mean": np.mean(loss_increases),
                     "logloss_increase_sd": np.std(loss_increases, ddof=1) if repeats > 1 else 0,
                     "repeats": repeats, "sample_n": len(sample), "random_seed": SEED})
    return pd.DataFrame(rows)


def make_x6(importance, out_dir):
    top = importance.sort_values("auc_drop_mean", ascending=False).head(12).iloc[::-1]
    fig, axes = plt.subplots(1, 2, figsize=(17 / 2.54, 8 / 2.54), sharey=True)
    display = [display_feature_name(f) for f in top.feature]
    axes[0].barh(display, top.auc_drop_mean, xerr=top.auc_drop_sd, color=NEG_COLOR, capsize=2)
    axes[0].set_xlabel("ROC-AUC decrease")
    axes[1].barh(display, top.logloss_increase_mean, xerr=top.logloss_increase_sd,
                 color=POS_COLOR, capsize=2)
    axes[1].set_xlabel("Log-loss increase")
    for label, ax in zip(("a", "b"), axes): style_axis(ax); panel_label(ax, label)
    fig.subplots_adjust(left=0.22, right=0.98, bottom=0.18, top=0.97, wspace=0.18)
    importance.to_csv(Path(out_dir) / "source_data" / "Figure_X6.csv", index=False, encoding="utf-8-sig")
    return importance, save_figure(fig, out_dir, "Figure_X6")


def ale_1d(model, sample, features, feature, bins, bootstrap_reps):
    x = pd.to_numeric(sample[feature], errors="coerce").to_numpy()
    edges = np.unique(np.nanquantile(x, np.linspace(0, 1, bins + 1)))
    if len(edges) < 3:
        return pd.DataFrame()
    bin_id = np.clip(np.digitize(x, edges[1:-1], right=True), 0, len(edges) - 2)
    effects, centers, counts, raw_effects = [], [], [], []
    for b in range(len(edges) - 1):
        idx = np.where((bin_id == b) & np.isfinite(x))[0]
        if len(idx) == 0:
            effects.append(np.nan); centers.append((edges[b] + edges[b + 1]) / 2); counts.append(0); raw_effects.append(np.array([])); continue
        low = sample.iloc[idx].copy(); high = sample.iloc[idx].copy()
        low[feature] = edges[b]; high[feature] = edges[b + 1]
        diff = model.predict(high[features], raw_score=True) - model.predict(low[features], raw_score=True)
        effects.append(np.mean(diff)); centers.append(np.mean(x[idx])); counts.append(len(idx)); raw_effects.append(diff)
    effects = np.nan_to_num(effects, nan=0.0)
    accumulated = np.cumsum(effects)
    weights = np.asarray(counts) / max(1, np.sum(counts))
    accumulated -= np.sum(accumulated * weights)
    rng = np.random.default_rng(SEED)
    boot = []
    for _ in range(bootstrap_reps):
        means = []
        for arr in raw_effects:
            means.append(np.mean(rng.choice(arr, len(arr), replace=True)) if len(arr) else 0.0)
        acc = np.cumsum(means); acc -= np.sum(acc * weights); boot.append(acc)
    boot = np.asarray(boot)
    return pd.DataFrame({"method": "ALE", "feature": feature, "bin": np.arange(1, len(centers) + 1),
                         "feature_value": centers, "ale": accumulated,
                         "ci_low": np.percentile(boot, 2.5, axis=0),
                         "ci_high": np.percentile(boot, 97.5, axis=0), "N": counts,
                         "bins": bins, "bootstrap_reps": bootstrap_reps,
                         "interpretation": "Associational response; not a causal effect"})


def pdp_1d(model, sample, features, feature, grid_points, bootstrap_reps):
    values = pd.to_numeric(sample[feature], errors="coerce").to_numpy(dtype=float)
    grid = np.unique(np.nanquantile(values, np.linspace(0.01, 0.99, grid_points)))
    if len(grid) < 3:
        return pd.DataFrame()
    predictions = []
    for value in grid:
        modified = sample.copy()
        modified[feature] = value
        predictions.append(model.predict(modified[features], raw_score=True))
    predictions = np.asarray(predictions, dtype=float)
    effect = predictions.mean(axis=1)
    effect -= effect.mean()
    rng = np.random.default_rng(SEED + len(feature))
    boot = []
    for _ in range(bootstrap_reps):
        idx = rng.integers(0, len(sample), len(sample))
        curve = predictions[:, idx].mean(axis=1)
        curve -= curve.mean()
        boot.append(curve)
    boot = np.asarray(boot)
    return pd.DataFrame({
        "method": "PDP", "feature": feature,
        "feature_value": grid, "pdp": effect,
        "ci_low": np.percentile(boot, 2.5, axis=0),
        "ci_high": np.percentile(boot, 97.5, axis=0),
        "grid_points": len(grid), "bootstrap_reps": bootstrap_reps,
        "sample_n": len(sample),
        "interpretation": "Associational partial dependence; not a causal effect",
    })


def make_x7(model, sample, features, continuous, out_dir, bootstrap_reps):
    selected = continuous[:6]
    ale_frames = [ale_1d(model, sample, features, f, 20, bootstrap_reps) for f in selected[:4]]
    pdp_frames = [pdp_1d(model, sample, features, f, 20, bootstrap_reps) for f in selected]
    ale_data = pd.concat([d for d in ale_frames if not d.empty], ignore_index=True)
    pdp_data = pd.concat([d for d in pdp_frames if not d.empty], ignore_index=True)
    fig, axes = plt.subplots(2, 3, figsize=(17 / 2.54, 13 / 2.54))
    legend_handles = [
        Line2D([0], [0], color=BLACK, lw=1.3, label="PDP curve"),
        Patch(facecolor=NEG_COLOR, alpha=0.14, label="Negative"),
        Patch(facecolor=POS_COLOR, alpha=0.14, label="Positive"),
    ]
    for ax, feature, panel in zip(axes.ravel(), selected, list("abcdef")):
        d = pdp_data[pdp_data.feature == feature]
        if d.empty:
            ax.set_visible(False); continue
        x = d.feature_value.to_numpy(dtype=float)
        x_plot, x_label = plotted_x(feature, x)
        effect = d.pdp.to_numpy(dtype=float)
        lo = d.ci_low.to_numpy(dtype=float); hi = d.ci_high.to_numpy(dtype=float)
        # Fill the complete panel height by the sign of the PDP response. Split
        # sign-changing intervals at their linearly interpolated zero crossing
        # so the green/purple background has no unfilled vertical seams.
        for i in range(len(x_plot) - 1):
            x0, x1 = float(x_plot[i]), float(x_plot[i + 1])
            y0, y1 = float(effect[i]), float(effect[i + 1])
            sign0, sign1 = y0 >= 0, y1 >= 0
            color0 = POS_COLOR if sign0 else NEG_COLOR
            if sign0 == sign1 or y1 == y0:
                ax.axvspan(x0, x1, color=color0, alpha=0.14,
                           linewidth=0, zorder=0)
            else:
                crossing = x0 + (0.0 - y0) * (x1 - x0) / (y1 - y0)
                color1 = POS_COLOR if sign1 else NEG_COLOR
                ax.axvspan(x0, crossing, color=color0, alpha=0.14,
                           linewidth=0, zorder=0)
                ax.axvspan(crossing, x1, color=color1, alpha=0.14,
                           linewidth=0, zorder=0)
        ax.fill_between(x_plot, lo, hi, color=POS_COLOR, alpha=0.10,
                        linewidth=0, zorder=1)
        ax.plot(x_plot, effect, color=BLACK, lw=1.3, zorder=3)
        ax.axhline(0, color=GREY, ls="--", lw=0.8, zorder=2)
        ax.set_xlim(float(np.min(x_plot)), float(np.max(x_plot)))
        y_min = float(np.nanmin(np.concatenate([lo, effect, np.array([0.0])])))
        y_max = float(np.nanmax(np.concatenate([hi, effect, np.array([0.0])])))
        y_pad = max(1e-6, (y_max - y_min) * 0.08)
        ax.set_ylim(y_min - y_pad, y_max + y_pad)
        ax.set_xlabel(textwrap.fill(x_label, width=16))
        ax.set_ylabel("Partial dependence")
        ax.legend(
            handles=legend_handles, loc="upper left", bbox_to_anchor=(0.08, 0.98),
            frameon=True, facecolor="white", edgecolor="none", framealpha=0.78,
            borderaxespad=0.0, handlelength=1.5, handletextpad=0.5,
            labelspacing=0.25,
        )
        style_axis(ax); panel_label(ax, panel)
    for ax in axes.ravel()[len(selected):]:
        ax.set_visible(False)
    fig.subplots_adjust(left=0.11, right=0.98, bottom=0.12, top=0.97,
                        wspace=0.50, hspace=0.48)
    pdp_data.to_csv(Path(out_dir) / "source_data" / "Figure_X7.csv", index=False, encoding="utf-8-sig")
    combined = pd.concat([ale_data, pdp_data], ignore_index=True, sort=False)
    return combined, save_figure(fig, out_dir, "Figure_X7")


def ensure_dirs(out_dir):
    for sub in ["models", "figures/png", "figures/pdf", "figures/svg", "tables",
                "source_data", "logs"]:
        (Path(out_dir) / sub).mkdir(parents=True, exist_ok=True)


def write_table(out_dir, name, frame):
    path = Path(out_dir) / "tables" / f"{name}.csv"
    frame.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def generate_reporting_bundle(*, model, study, features, categorical, final_train,
                              valid, test, p_train, p_valid, p_test,
                              y_threshold, p_threshold, audit_path, out_dir,
                              smoke, run_config, runtime_log):
    out_dir = Path(out_dir); ensure_dirs(out_dir)
    abbreviation_table = feature_abbreviation_table(features)
    abbreviation_table.to_csv(
        out_dir / "feature_abbreviation_table.csv", index=False, encoding="utf-8-sig"
    )
    bootstrap_reps = 20 if smoke else 500
    threshold = choose_youden_threshold(y_threshold, p_threshold)
    metrics_train = classification_metrics(final_train.y_denied, p_train, threshold, "2018-2022 train")
    metrics_valid = classification_metrics(valid.y_denied, p_valid, threshold, "2023 validation")
    metrics_test = classification_metrics(test.y_denied, p_test, threshold, "2024 test")
    metrics_valid.update(bootstrap_cis(valid.y_denied, p_valid, threshold, bootstrap_reps, SEED + 1))
    metrics_test.update(bootstrap_cis(test.y_denied, p_test, threshold, bootstrap_reps, SEED + 2))
    calibration = pd.concat([
        calibration_bins(valid.y_denied, p_valid, "2023 validation"),
        calibration_bins(test.y_denied, p_test, "2024 test"),
    ], ignore_index=True)
    threshold_curve = threshold_metrics(test.y_denied, p_test)
    counts, rates = confusion_tables(test.y_denied, p_test, threshold)
    stability = state_year_metrics(valid, p_valid, test, p_test, threshold, bootstrap_reps)
    audit = load_group_audit(audit_path, test.application_row_id.to_numpy())
    groups = group_audit_table(audit, test.y_denied, p_test, threshold, bootstrap_reps)

    figure_files = []
    if study is not None:
        _, paths = make_m1(study, out_dir); figure_files += paths
    _, paths = make_m2(valid.y_denied, p_valid, test.y_denied, p_test, out_dir); figure_files += paths
    _, paths = make_m3(calibration, test.y_denied, p_test, threshold, metrics_valid, metrics_test, out_dir); figure_files += paths
    _, paths = make_m4(counts, rates, threshold_curve, threshold, out_dir); figure_files += paths
    _, paths = make_m5(stability, out_dir); figure_files += paths
    _, paths = make_m6(groups, out_dir); figure_files += paths

    sample, sample_p, shap_values, base_values, shap_index, shap_global, top10, feature_index, numeric_matrix = shap_analysis(
        model, test, p_test, features, categorical, threshold, out_dir, smoke)
    shap_global.to_csv(out_dir / "tables" / "SHAP_Global_Importance.csv", index=False, encoding="utf-8-sig")
    shap_index.to_csv(out_dir / "tables" / "SHAP_Sample_Index.csv", index=False, encoding="utf-8-sig")
    x1, paths = make_x1(sample, shap_values, shap_global, top10, feature_index, numeric_matrix, out_dir); figure_files += paths
    x2, paths, dependence_table, continuous = make_x2(
        sample, shap_values, shap_global, top10, feature_index, numeric_matrix,
        features, categorical, out_dir
    ); figure_files += paths
    x3, paths = make_x3(shap_values, shap_global, feature_index, out_dir); figure_files += paths
    x4, paths = make_x4(sample, sample_p, shap_values, top10, feature_index, out_dir, smoke); figure_files += paths
    local_cases, paths = make_x5(sample, sample_p, shap_values, base_values, top10, feature_index, threshold, out_dir); figure_files += paths
    permutation = permutation_importance(model, test, p_test, features,
                                         2 if smoke else 5, 2000 if smoke else 30000)
    _, paths = make_x6(permutation, out_dir); figure_files += paths
    ale_data, paths = make_x7(model, sample, features, continuous[:6], out_dir,
                              20 if smoke else 500); figure_files += paths

    shap_group = x1.groupby(["class", "class_label", "feature", "definition"], as_index=False).agg(
        mean_abs_shap=("shap_value", lambda x: np.mean(np.abs(x))),
        mean_shap=("shap_value", "mean"), N=("shap_value", "size"))
    figure_index = pd.DataFrame([{
        "figure": path.stem, "format": path.suffix.lstrip("."),
        "file": str(path.relative_to(out_dir)), "size_bytes": path.stat().st_size,
        "source_data": f"source_data/{path.stem}.csv",
    } for path in figure_files])
    run_config_table = pd.DataFrame([{"item": k, "value": json.dumps(v, ensure_ascii=False)
                                     if isinstance(v, (dict, list)) else v}
                                    for k, v in {**run_config, "threshold_rule": "Maximize Youden J on 2022",
                                                 "selected_threshold": threshold,
                                                 "bootstrap_reps": bootstrap_reps}.items()])
    data_splits = pd.DataFrame([
        {"split": "Optimization train", "years": "2018-2021", "N": int((final_train.x_activity_year <= 2021).sum())},
        {"split": "Optimization validation", "years": "2022", "N": int((final_train.x_activity_year == 2022).sum())},
        {"split": "Final refit", "years": "2018-2022", "N": len(final_train)},
        {"split": "External validation", "years": "2023", "N": len(valid)},
        {"split": "Final test", "years": "2024", "N": len(test)},
    ])
    if study is not None:
        trials = study.trials_dataframe()
        parameter_rows = [
            {"parameter": k, "value": v, "role": "Optimized"}
            for k, v in study.best_params.items()
        ]
    else:
        trials = pd.DataFrame([{
            "status": "Not applicable",
            "detail": "This baseline uses pre-specified parameters and no Optuna search.",
        }])
        parameter_rows = [
            {"parameter": k, "value": v, "role": "Pre-specified"}
            for k, v in run_config.get("model_parameters", {}).items()
        ]
    best_params = pd.DataFrame(parameter_rows + [
        {"parameter": "threshold", "value": threshold,
         "role": "Selected by Youden J on 2022"}
    ])
    tables = {
        "Run_Config": run_config_table, "Data_Splits": data_splits,
        "Optuna_Trials": trials, "Best_Parameters": best_params,
        "Metrics_Train": pd.DataFrame([metrics_train]),
        "Metrics_Validation_2023": pd.DataFrame([metrics_valid]),
        "Metrics_Test_2024": pd.DataFrame([metrics_test]),
        "Threshold_Metrics": threshold_curve,
        "Confusion_Matrix_Counts": counts,
        "Confusion_Matrix_Rates": rates,
        "Calibration_Bins": calibration,
        "State_Year_Metrics": stability,
        "Group_Audit": groups,
        "SHAP_Global_Importance": shap_global,
        "SHAP_Group_Comparison": shap_group,
        "SHAP_Dependence_Data": dependence_table,
        "SHAP_Local_Cases": local_cases,
        "SHAP_Sample_Index": shap_index,
        "Permutation_Importance": permutation,
        "ALE_Data": ale_data,
        "Figure_Index": figure_index,
        "Runtime_Log": pd.DataFrame(runtime_log),
    }
    for name, frame in tables.items(): write_table(out_dir, name, frame)
    return {"tables": tables, "figure_files": figure_files, "threshold": threshold,
            "shap_shape": shap_values.shape, "feature_count": len(features),
            "abbreviation_table": abbreviation_table,
            "warnings": [], "figure_count": len(set(p.stem for p in figure_files))}
