# Optuna-optimized LightGBM

Run these scripts in the VSCode Base terminal from this folder.

Install the optimization dependency once:

```powershell
python -m pip install optuna matplotlib
```

Formal run with 100 trials:

```powershell
python run_lightgbm_optuna.py
```

The optimization is intentionally limited to five core parameters: `learning_rate`, `num_leaves`, `min_child_samples`, `feature_fraction`, and `lambda_l2`. Other structural and sampling parameters remain fixed for speed and interpretability.

When an existing study is found, the default `ask` mode prompts you to choose whether to resume or overwrite it. To skip the prompt, use one of these commands:

```powershell
# Continue until the study contains 100 total trials.
python run_lightgbm_optuna.py --trials 100 --study-mode resume

# Delete the previous formal study and start a new 100-trial run.
python run_lightgbm_optuna.py --trials 100 --study-mode overwrite
```

Optional quick test:

```powershell
python run_lightgbm_optuna.py --smoke-test --study-mode overwrite
```

Formal Optuna outputs are written to `results`. The two-trial test is written to `smoke_test_2trials` and cannot overwrite formal outputs.

The optimized run also produces:

- a complete Excel results workbook;
- fitness history and all Optuna trials;
- selected hyperparameters and parameter importance;
- train/validation/test metrics and calibration tables;
- metrics by year and state;
- feature importance and complete Parquet predictions;
- 600 dpi PNG plus editable PDF/SVG fitness and parallel-coordinate figures.
