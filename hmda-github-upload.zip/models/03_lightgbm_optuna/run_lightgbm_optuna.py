"""Optuna-TPE optimized LightGBM for the HMDA study.

Install once in the VSCode Base terminal:
    python -m pip install lightgbm optuna pandas pyarrow numpy scipy

Formal full-sample run (100 trials):
    python run_lightgbm_optuna.py

Explicitly resume or overwrite an existing study:
    python run_lightgbm_optuna.py --trials 100 --study-mode resume
    python run_lightgbm_optuna.py --trials 100 --study-mode overwrite

Optional two-trial smoke test that preserves the natural class distribution:
    python run_lightgbm_optuna.py --smoke-test --study-mode overwrite

Design:
    2018-2021  Optuna training
    2022       Optuna temporal validation (minimize binary log loss)
    2018-2022  final refit with the selected parameters
    2023       external validation
    2024       final untouched test
"""

from __future__ import annotations

import argparse
import gc
import json
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import lightgbm as lgb
    import matplotlib as mpl
    import matplotlib.font_manager as font_manager
    import matplotlib.pyplot as plt
    import optuna
    import pyarrow
    import pyarrow.parquet as pq
except ImportError as exc:
    raise SystemExit(
        "缺少依赖。请在VSCode Base终端运行：\n"
        "python -m pip install lightgbm optuna pandas pyarrow numpy scipy matplotlib\n"
        f"具体错误：{exc}"
    ) from exc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "data" / "data" / "modeling" / "main_homogeneous_peer.parquet"
AUDIT_DATA = ROOT / "data" / "data" / "modeling" / "main_homogeneous_audit.parquet"
OUT = HERE / "results"
FIGURES = OUT / "figures"
SEED = 20260731

from model_reporting import CMAP, NEG_COLOR, POS_COLOR, generate_reporting_bundle

mpl.rcParams.update({
    "font.family": "Times New Roman",
    "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
    "font.size": 11,
    "axes.titlesize": 11,
    "axes.labelsize": 11,
    "xtick.labelsize": 11,
    "ytick.labelsize": 11,
    "legend.fontsize": 11,
    "legend.title_fontsize": 11,
    "axes.spines.top": True,
    "axes.spines.right": True,
    "axes.linewidth": 0.8,
    "legend.frameon": False,
    "pdf.fonttype": 42,
    "svg.fonttype": "none",
})


def auc(y, p):
    y = np.asarray(y, dtype=np.int8)
    p = np.asarray(p, dtype=float)
    order = np.argsort(p, kind="mergesort")
    ranks = np.arange(1, len(y) + 1, dtype=float)
    sorted_p = p[order]
    i = 0
    while i < len(sorted_p):
        j = i + 1
        while j < len(sorted_p) and sorted_p[j] == sorted_p[i]:
            j += 1
        ranks[i:j] = ranks[i:j].mean()
        i = j
    positives = int(y.sum())
    negatives = len(y) - positives
    if positives == 0 or negatives == 0:
        return np.nan
    return float(
        (ranks[y[order] == 1].sum() - positives * (positives + 1) / 2)
        / (positives * negatives)
    )


def average_precision(y, p):
    y = np.asarray(y, dtype=np.int8)
    order = np.argsort(-np.asarray(p), kind="mergesort")
    sorted_y = y[order]
    positives = int(sorted_y.sum())
    if positives == 0:
        return np.nan
    cumulative = np.cumsum(sorted_y)
    ranks = np.arange(1, len(sorted_y) + 1)
    return float((cumulative[sorted_y == 1] / ranks[sorted_y == 1]).sum() / positives)


def metric_row(split, y, p):
    y = np.asarray(y, dtype=np.int8)
    p = np.clip(np.asarray(p, dtype=float), 1e-15, 1 - 1e-15)
    pred = (p >= 0.5).astype(np.int8)
    tp = int(((pred == 1) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    return {
        "split": split,
        "N": len(y),
        "denial_rate": float(y.mean()),
        "auc": auc(y, p),
        "average_precision": average_precision(y, p),
        "log_loss": float(-(y * np.log(p) + (1 - y) * np.log(1 - p)).mean()),
        "brier_score": float(np.mean((p - y) ** 2)),
        "accuracy_at_0_5": float((pred == y).mean()),
        "precision_at_0_5": tp / (tp + fp) if tp + fp else np.nan,
        "recall_at_0_5": tp / (tp + fn) if tp + fn else np.nan,
        "specificity_at_0_5": tn / (tn + fp) if tn + fp else np.nan,
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
    }


def calibration_table(split, y, p, bins=10):
    data = pd.DataFrame({"y": np.asarray(y, dtype=np.int8), "p": np.asarray(p, dtype=float)})
    data["bin"] = pd.qcut(data["p"], q=bins, duplicates="drop")
    out = data.groupby("bin", observed=True).agg(
        N=("y", "size"),
        mean_predicted_probability=("p", "mean"),
        observed_denial_rate=("y", "mean"),
        min_predicted_probability=("p", "min"),
        max_predicted_probability=("p", "max"),
    ).reset_index(drop=True)
    out.insert(0, "probability_bin", np.arange(1, len(out) + 1))
    out.insert(0, "split", split)
    return out


def grouped_metrics(frame, probabilities, split):
    data = pd.DataFrame({
        "year": frame["x_activity_year"].to_numpy(),
        "state": frame["x_state_code"].astype("string").to_numpy(),
        "y": frame["y_denied"].to_numpy(),
        "p": np.asarray(probabilities),
    })
    rows = []
    for (year, state), group in data.groupby(["year", "state"], dropna=False):
        row = metric_row(split, group["y"], group["p"])
        row["year"] = int(year)
        row["state"] = str(state)
        rows.append(row)
    columns = ["split", "year", "state"] + [
        c for c in metric_row("template", np.array([0, 1]), np.array([0.1, 0.9])).keys()
        if c != "split"
    ]
    return pd.DataFrame(rows).reindex(columns=columns)


def trial_history(study):
    rows = []
    best_so_far = np.inf
    for trial in sorted(study.trials, key=lambda t: t.number):
        if trial.value is not None and np.isfinite(trial.value):
            value = float(trial.value)
        elif trial.intermediate_values:
            value = float(trial.intermediate_values[max(trial.intermediate_values)])
        else:
            value = np.nan
        if np.isfinite(value):
            best_so_far = min(best_so_far, value)
        rows.append({
            "trial": int(trial.number),
            "state": trial.state.name,
            "current_fitness_logloss": value,
            "best_fitness_so_far": best_so_far if np.isfinite(best_so_far) else np.nan,
            "best_iteration": trial.user_attrs.get("best_iteration", np.nan),
        })
    return pd.DataFrame(rows)


def save_figure_bundle(fig, stem):
    FIGURES.mkdir(parents=True, exist_ok=True)
    fig.savefig(FIGURES / f"{stem}.svg")
    fig.savefig(FIGURES / f"{stem}.pdf")
    fig.savefig(FIGURES / f"{stem}.png", dpi=600)
    plt.close(fig)


def plot_fitness(history, suffix):
    data = history[np.isfinite(history["current_fitness_logloss"])].copy()
    if data.empty:
        return
    fig, ax = plt.subplots(figsize=(8.0 / 2.54, 7.0 / 2.54))
    ax.scatter(data["trial"], data["current_fitness_logloss"],
               color=NEG_COLOR, s=18, alpha=0.72, edgecolors="none",
               label="Trial fitness", zorder=2)
    ax.step(data["trial"], data["best_fitness_so_far"], where="post",
            color=POS_COLOR, linewidth=1.5, label="Best fitness", zorder=3)
    ax.set_xlabel("Trial")
    ax.set_ylabel("Validation log loss")
    ax.tick_params(axis="both", direction="out", length=3.5, width=0.8,
                   top=False, right=False)
    ax.legend(loc="best", handlelength=2.2, borderaxespad=0.4)
    ax.grid(False)
    fig.subplots_adjust(left=0.24, right=0.97, bottom=0.22, top=0.97)
    save_figure_bundle(fig, f"fitness_curve_{suffix}")


def plot_parallel_coordinates(study, suffix):
    completed = [t for t in study.trials
                 if t.state == optuna.trial.TrialState.COMPLETE and t.value is not None]
    if len(completed) < 2:
        return
    parameter_order = [
        "learning_rate", "num_leaves", "min_child_samples",
        "feature_fraction", "lambda_l2",
    ]
    records = []
    for trial in completed:
        record = {p: float(trial.params[p]) for p in parameter_order}
        record["validation_logloss"] = float(trial.value)
        records.append(record)
    data = pd.DataFrame(records)
    display_order = parameter_order + ["validation_logloss"]
    normalized = pd.DataFrame(index=data.index)
    for column in display_order:
        values = data[column].astype(float)
        lo, hi = values.min(), values.max()
        normalized[column] = 0.5 if hi == lo else (values - lo) / (hi - lo)
    objective = data["validation_logloss"].to_numpy()
    norm = mpl.colors.Normalize(vmin=objective.min(), vmax=objective.max())
    cmap = CMAP
    x = np.arange(len(display_order))
    fig, ax = plt.subplots(figsize=(8.0 / 2.54, 5.8 / 2.54))
    for i in range(len(data)):
        ax.plot(x, normalized.iloc[i].to_numpy(),
                color=cmap(norm(objective[i])), linewidth=0.75, alpha=0.58)
    labels = [
        "Learn. rate", "Leaves", "Min. child",
        "Feat. frac.", "L2", "Log loss",
    ]
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=27, ha="right", rotation_mode="anchor")
    ax.set_ylim(-0.04, 1.04)
    ax.set_ylabel("Normalized value")
    ax.tick_params(axis="both", direction="out", length=3.2, width=0.8,
                   top=False, right=False)
    ax.grid(axis="x", color="#D9D9D9", linewidth=0.45, alpha=0.65)
    scalar = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    cbar = fig.colorbar(scalar, ax=ax, pad=0.025, fraction=0.06)
    cbar.set_label("Log loss", fontsize=11)
    cbar.ax.tick_params(labelsize=11, length=3, width=0.8)
    fig.subplots_adjust(left=0.20, right=0.82, bottom=0.34, top=0.96)
    save_figure_bundle(fig, f"parallel_coordinates_{suffix}")


def save_csv(frame, filename):
    table_dir = OUT / "tables"
    table_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(table_dir / filename, index=False, encoding="utf-8-sig")


def build_excel_workbook():
    """Use the bundled artifact-tool workbook builder when its Node runtime exists."""
    builder = HERE / "build_optuna_workbook.mjs"
    node = shutil.which("node")
    if node is None:
        bundled = (Path.home() / ".cache" / "codex-runtimes" /
                   "codex-primary-runtime" / "dependencies" / "node" / "bin" / "node.exe")
        if bundled.exists():
            node = str(bundled)
    if node is None or not builder.exists():
        print("Excel build skipped: bundled Node runtime or workbook builder was not found.")
        return
    try:
        subprocess.run([str(node), str(builder), str(OUT)], check=True)
        return True
    except subprocess.CalledProcessError as exc:
        print(f"Excel build failed, but CSV/Parquet results are intact: {exc}")
        return False


def write_smoke_test_report(reporting, excel_ok, elapsed_seconds):
    """Write a compact, machine-checkable two-trial smoke-test verdict."""
    import xml.etree.ElementTree as ET

    expected_figures = [f"Figure_M{i}" for i in range(1, 7)] + [
        "Figure_X1", "Figure_X2", "Figure_X3", "Figure_X4",
        "Figure_X5_TN", "Figure_X5_TP", "Figure_X5_FP", "Figure_X5_FN",
        "Figure_X6", "Figure_X7",
    ]
    checks = []

    def add(name, passed, detail, warning=False):
        checks.append({
            "check": name,
            "result": "PASS" if passed else ("WARNING" if warning else "FAIL"),
            "detail": detail,
        })

    completed = [
        t for t in reporting["study"].trials
        if t.state == optuna.trial.TrialState.COMPLETE
    ]
    add("Exactly two completed Optuna trials", len(completed) == 2,
        f"completed_trials={len(completed)}")

    missing = []
    empty = []
    unreadable = []
    for stem in expected_figures:
        source = OUT / "source_data" / f"{stem}.csv"
        if not source.exists() or source.stat().st_size == 0:
            missing.append(str(source.relative_to(OUT)))
        for fmt in ("png", "pdf", "svg"):
            path = OUT / "figures" / fmt / f"{stem}.{fmt}"
            if not path.exists():
                missing.append(str(path.relative_to(OUT)))
            elif path.stat().st_size == 0:
                empty.append(str(path.relative_to(OUT)))
            else:
                try:
                    if fmt == "png":
                        image = plt.imread(path)
                        if image.size == 0:
                            raise ValueError("empty image array")
                    elif fmt == "pdf":
                        if not path.read_bytes().startswith(b"%PDF"):
                            raise ValueError("invalid PDF header")
                    else:
                        ET.parse(path)
                except Exception as exc:
                    unreadable.append(f"{path.relative_to(OUT)}: {exc}")
    add(f"All {len(expected_figures)} figures and source CSVs", not missing and not empty,
        f"missing={missing or 'none'}; empty={empty or 'none'}")
    add("PNG/PDF/SVG files open successfully", not unreadable,
        f"unreadable={unreadable or 'none'}")
    add("Figure count", reporting["figure_count"] == len(expected_figures),
        f"unique_figure_stems={reporting['figure_count']}")

    expected_17cm = [
        "Figure_M6", "Figure_X1", "Figure_X2", "Figure_X3", "Figure_X4",
        "Figure_X5_TN", "Figure_X5_TP", "Figure_X5_FP", "Figure_X5_FN",
    ]
    width_issues = []
    measured_widths = {}
    for stem in expected_17cm:
        png_path = OUT / "figures" / "png" / f"{stem}.png"
        if not png_path.exists():
            width_issues.append(f"{stem}=missing")
            continue
        pixels = plt.imread(png_path).shape[1]
        width_cm = pixels / 600 * 2.54
        measured_widths[stem] = round(width_cm, 3)
        if abs(width_cm - 17.0) > 0.03:
            width_issues.append(f"{stem}={width_cm:.3f}cm")
    add("M6 and X1-X5 figure widths are 17 cm", not width_issues,
        f"measured_widths_cm={measured_widths}; issues={width_issues or 'none'}")

    validation_path = OUT / "workbook_validation.json"
    workbook_detail = "validation file missing"
    workbook_pass = False
    if validation_path.exists():
        validation = json.loads(validation_path.read_text(encoding="utf-8"))
        workbook_pass = (
            excel_ok and validation.get("sheet_count") == 22
            and validation.get("rendered_sheet_count") == 22
            and validation.get("formula_error_count") == 0
            and validation.get("abbreviation_sheet_count") == 1
            and validation.get("abbreviation_row_count") == reporting["feature_count"]
            and validation.get("abbreviation_formula_error_count") == 0
            and validation.get("abbreviation_rendered") is True
            and (OUT / "feature_abbreviation_table.xlsx").exists()
        )
        workbook_detail = json.dumps(validation, ensure_ascii=False)
    add("Excel workbooks: 22 result sheets plus abbreviation key, rendered, no formula errors",
        workbook_pass, workbook_detail)

    shap_shape = tuple(reporting["shap_shape"])
    add("SHAP matrix dimensions", len(shap_shape) == 2 and
        shap_shape[1] == reporting["feature_count"],
        f"shape={shap_shape}; feature_count={reporting['feature_count']}")

    abbreviation_table = reporting["abbreviation_table"]
    abbreviation_ok = (
        len(abbreviation_table) == reporting["feature_count"]
        and abbreviation_table["abbreviation"].notna().all()
        and abbreviation_table["abbreviation"].astype(str).str.strip().ne("").all()
        and abbreviation_table["abbreviation"].is_unique
        and abbreviation_table["model_variable"].is_unique
        and abbreviation_table["figure_scale_or_unit"].notna().all()
        and (OUT / "feature_abbreviation_table.csv").exists()
    )
    add("Feature abbreviation key is complete, unique, and unit-documented",
        abbreviation_ok,
        f"rows={len(abbreviation_table)}; abbreviations="
        f"{abbreviation_table['abbreviation'].tolist()}")

    forbidden_figure_text = [
        "SHAP value (", "(log-odds)", "Partial dependence (",
        "Class 0 (", "Class 1 (", "million USD", "thousand USD", "$",
    ]
    figure_label_issues = []
    for stem in [f"Figure_X{i}" for i in range(1, 8)]:
        candidates = list((OUT / "figures" / "svg").glob(f"{stem}*.svg"))
        for svg_path in candidates:
            svg_text = svg_path.read_text(encoding="utf-8", errors="replace")
            found = [token for token in forbidden_figure_text if token in svg_text]
            if found:
                figure_label_issues.append(f"{svg_path.name}: {found}")
    add("Explainability figures use concise unit-free axis labels",
        not figure_label_issues,
        f"issues={figure_label_issues or 'none'}")

    x7_legend_ok = False
    x7_legend_detail = "Figure_X7.svg missing"
    x7_svg = OUT / "figures" / "svg" / "Figure_X7.svg"
    if x7_svg.exists():
        x7_text = x7_svg.read_text(encoding="utf-8", errors="replace")
        counts = {label: x7_text.count(label) for label in
                  ("PDP curve", "Negative", "Positive")}
        x7_legend_ok = all(count == 6 for count in counts.values())
        x7_legend_detail = f"legend_label_counts={counts}"
    add("Figure X7 repeats the three-item legend inside all six panels",
        x7_legend_ok, x7_legend_detail)

    legend_issues = []
    for stem in ("Figure_M2", "Figure_M3"):
        svg_path = OUT / "figures" / "svg" / f"{stem}.svg"
        if not svg_path.exists():
            legend_issues.append(f"{stem}=missing")
            continue
        svg_text = svg_path.read_text(encoding="utf-8", errors="replace")
        if "2023 validation" in svg_text or "2024 test" in svg_text:
            legend_issues.append(f"{stem}=year-specific legend remains")
        if "Validation set" not in svg_text or "Test set" not in svg_text:
            legend_issues.append(f"{stem}=generic legend labels missing")
    add("Validation/test figure legends omit calendar years",
        not legend_issues, f"issues={legend_issues or 'none'}")

    x1_stack_issues = []
    try:
        x1_source = pd.read_csv(OUT / "source_data" / "Figure_X1.csv")
        x1_stack = x1_source[[
            "feature", "class", "importance_stack_start", "importance_stack_end"
        ]].drop_duplicates()
        class0 = x1_stack[x1_stack["class"] == 0].set_index("feature")
        class1 = x1_stack[x1_stack["class"] == 1].set_index("feature")
        shared = class0.index.intersection(class1.index)
        if len(shared) != reporting["tables"]["SHAP_Global_Importance"].head(10).shape[0]:
            x1_stack_issues.append(f"shared_features={len(shared)}")
        if not np.allclose(class0.loc[shared, "importance_stack_start"], 0.0):
            x1_stack_issues.append("Class 0 does not start at zero")
        if not np.allclose(
            class0.loc[shared, "importance_stack_end"],
            class1.loc[shared, "importance_stack_start"],
        ):
            x1_stack_issues.append("Class 1 does not start at Class 0 endpoint")
    except Exception as exc:
        x1_stack_issues.append(str(exc))
    add("Figure X1 importance bars use one cumulative left-to-right stack",
        not x1_stack_issues, f"issues={x1_stack_issues or 'none'}")

    table_names = list(reporting["tables"].keys())
    missing_tables = [name for name in table_names
                      if not (OUT / "tables" / f"{name}.csv").exists()]
    add("All 22 workbook source tables", len(table_names) == 22 and not missing_tables,
        f"table_count={len(table_names)}; missing={missing_tables or 'none'}")

    consistency_pairs = {
        "Figure_M5.csv": "State_Year_Metrics.csv",
        "Figure_M6.csv": "Group_Audit.csv",
        "Figure_X6.csv": "Permutation_Importance.csv",
    }
    inconsistent = []
    for figure_csv, table_csv in consistency_pairs.items():
        try:
            figure_frame = pd.read_csv(OUT / "source_data" / figure_csv)
            table_frame = pd.read_csv(OUT / "tables" / table_csv)
            pd.testing.assert_frame_equal(
                figure_frame, table_frame, check_dtype=False, check_like=True,
                rtol=1e-10, atol=1e-12,
            )
        except Exception as exc:
            inconsistent.append(f"{figure_csv}<->{table_csv}: {exc}")
    try:
        figure_pdp = pd.read_csv(OUT / "source_data" / "Figure_X7.csv")
        response_table = pd.read_csv(OUT / "tables" / "ALE_Data.csv")
        table_pdp = response_table[response_table["method"] == "PDP"].reset_index(drop=True)
        table_pdp = table_pdp.reindex(columns=figure_pdp.columns)
        pd.testing.assert_frame_equal(
            figure_pdp.reset_index(drop=True), table_pdp,
            check_dtype=False, check_like=True, rtol=1e-10, atol=1e-12,
        )
    except Exception as exc:
        inconsistent.append(f"Figure_X7.csv<->ALE_Data.csv[PDP]: {exc}")
    add("Figure source data agree with Excel source tables", not inconsistent,
        f"checked_pairs={len(consistency_pairs) + 1}; differences={inconsistent or 'none'}")

    numeric_issues = []
    for name, frame in reporting["tables"].items():
        numeric = frame.select_dtypes(include=[np.number])
        if not numeric.empty and np.isinf(numeric.to_numpy(dtype=float)).any():
            numeric_issues.append(name)
    add("No infinite numeric results", not numeric_issues,
        f"tables_with_inf={numeric_issues or 'none'}")

    try:
        font_path = font_manager.findfont("Times New Roman", fallback_to_default=False)
        font_ok = bool(font_path)
    except Exception as exc:
        font_ok = False
        font_path = str(exc)
    svg_without_font = []
    for stem in expected_figures:
        svg_path = OUT / "figures" / "svg" / f"{stem}.svg"
        if svg_path.exists() and "Times New Roman" not in svg_path.read_text(
            encoding="utf-8", errors="ignore"
        ):
            svg_without_font.append(stem)
    add("Times New Roman available and declared in SVG", font_ok and not svg_without_font,
        f"font_file={font_path}; SVG_without_declaration={svg_without_font or 'none'}",
        warning=True)

    local_cases = reporting["tables"]["SHAP_Local_Cases"]
    found_cases = set(local_cases.get("case_type", pd.Series(dtype=str)).dropna().astype(str))
    required_cases = {"True negative", "True positive", "False positive", "False negative"}
    add("Local SHAP cases TN/TP/FP/FN", required_cases.issubset(found_cases),
        f"found={sorted(found_cases)}", warning=True)

    has_fail = any(x["result"] == "FAIL" for x in checks)
    has_warning = any(x["result"] == "WARNING" for x in checks)
    verdict = "FAIL" if has_fail else ("PASS WITH WARNINGS" if has_warning else "PASS")
    lines = [
        "# LightGBM unified workflow smoke-test report",
        "",
        f"**Overall verdict: {verdict}**",
        "",
        f"- Output directory: `{OUT}`",
        f"- Elapsed time: {elapsed_seconds:.1f} seconds",
        f"- Trial count requested: 2",
        f"- Per-year cap: 50,000 natural-distribution records",
        "- Formal full-sample training automatically started: No",
        "",
        "| Check | Result | Detail |",
        "|---|---|---|",
    ]
    for item in checks:
        detail = str(item["detail"]).replace("|", "\\|").replace("\n", " ")
        lines.append(f"| {item['check']} | {item['result']} | {detail} |")
    (OUT / "smoke_test_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    pd.DataFrame(checks).to_csv(
        OUT / "logs" / "smoke_test_checks.csv", index=False, encoding="utf-8-sig"
    )
    return verdict


def save_lightgbm_model(model, destination):
    """Work around LightGBM's Windows write failure on non-ASCII paths."""
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="hmda_lgb_model_") as temp_dir:
        temporary_model = Path(temp_dir) / "lightgbm_model.txt"
        model.save_model(str(temporary_model))
        shutil.copy2(temporary_model, destination)


def align_categories(training, evaluation_frames, categorical):
    """Learn category levels from training only; unseen future levels become UNKNOWN."""
    for column in categorical:
        train_values = training[column].astype("string").fillna("__MISSING__")
        categories = train_values.drop_duplicates().tolist()
        if "__UNKNOWN__" not in categories:
            categories.append("__UNKNOWN__")
        training[column] = pd.Categorical(train_values, categories=categories)
        category_set = set(categories)
        for frame in evaluation_frames:
            values = frame[column].astype("string").fillna("__MISSING__")
            values = values.where(values.isin(category_set), "__UNKNOWN__")
            frame[column] = pd.Categorical(values, categories=categories)


def pruning_callback(trial):
    """Report validation log loss to Optuna without optuna-integration."""
    def callback(env):
        for data_name, metric_name, value, _ in env.evaluation_result_list:
            if data_name == "validation_2022" and metric_name == "binary_logloss":
                trial.report(float(value), step=env.iteration)
                if trial.should_prune():
                    raise optuna.TrialPruned()
                break
    callback.order = 20
    return callback


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--trials", type=int, default=100,
                        help="Total Optuna trials for this study (default: 100).")
    parser.add_argument("--max-rows-per-year", type=int, default=None,
                        help="Optional natural-distribution sample for a smoke run.")
    parser.add_argument("--threads", type=int, default=-1,
                        help="LightGBM CPU threads; -1 uses all logical cores.")
    parser.add_argument(
        "--study-mode", choices=["ask", "resume", "overwrite", "cancel"], default="ask",
        help=("ask: prompt when an existing study is found; resume: continue to "
              "the requested total trial count; overwrite: delete and restart; cancel: exit."),
    )
    parser.add_argument(
        "--smoke-test", action="store_true",
        help="Run the complete two-trial workflow on at most 50,000 rows per year.",
    )
    # VSCode's Jupyter/IPython runner automatically injects --f=kernel.json.
    # parse_known_args keeps the script runnable both as a .py file and in an
    # interactive kernel while preserving our own command-line arguments.
    args, unknown_args = parser.parse_known_args()
    if unknown_args:
        print(f"Ignoring VSCode/Jupyter arguments: {unknown_args}")
    started = time.time()
    runtime_log = [{
        "stage": "run_started", "status": "OK", "elapsed_seconds": 0.0,
        "detail": "Unified LightGBM-Optuna workflow initialized",
    }]
    if args.study_mode == "cancel":
        print("Run cancelled by user.")
        return
    if args.smoke_test:
        args.trials = 2
        args.max_rows_per_year = 50000
    global OUT, FIGURES
    OUT = HERE / ("smoke_test_2trials" if args.smoke_test else "results")
    FIGURES = OUT / "figures"
    OUT.mkdir(parents=True, exist_ok=True)
    for sub in ["models", "figures/png", "figures/pdf", "figures/svg",
                "tables", "source_data", "logs"]:
        (OUT / sub).mkdir(parents=True, exist_ok=True)
    if not DATA.exists() or not AUDIT_DATA.exists():
        raise FileNotFoundError(f"找不到data文件：{DATA}")

    schema = pq.ParquetFile(DATA).schema.names
    features = [c for c in schema if c.startswith("x_") and c != "x_activity_year"]
    columns = ["application_row_id", "y_denied", "x_activity_year", *features]
    df = pd.read_parquet(DATA, columns=list(dict.fromkeys(columns)), engine="pyarrow")
    df["y_denied"] = pd.to_numeric(df["y_denied"], errors="raise").astype("int8")
    df["x_activity_year"] = pd.to_numeric(
        df["x_activity_year"], errors="raise"
    ).astype("int16")
    if args.max_rows_per_year:
        df = (
            df.groupby("x_activity_year", group_keys=False)
            .apply(lambda g: g.sample(
                min(len(g), args.max_rows_per_year), random_state=SEED
            ))
            .reset_index(drop=True)
        )

    categorical = [c for c in [
        "x_state_code", "x_county_code", "x_msa_md", "x_preapproval",
        "x_loan_type", "x_dti_category",
    ] if c in features]
    for c in features:
        if c not in categorical and not pd.api.types.is_numeric_dtype(df[c]):
            df[c] = pd.to_numeric(df[c], errors="coerce")

    # Phase 1: tune only on past years, using 2022 as a temporal holdout.
    tune_train = df[df["x_activity_year"].between(2018, 2021)].copy()
    tune_valid = df[df["x_activity_year"] == 2022].copy()
    align_categories(tune_train, [tune_valid], categorical)
    print(f"Optuna train 2018-2021: {len(tune_train):,}")
    print(f"Optuna validation 2022: {len(tune_valid):,}")
    print("Optimization target: validation binary log loss (lower is better).")

    dtrain = lgb.Dataset(
        tune_train[features], label=tune_train["y_denied"],
        categorical_feature=categorical, free_raw_data=False,
        params={"feature_pre_filter": False},
    )
    dvalid = lgb.Dataset(
        tune_valid[features], label=tune_valid["y_denied"],
        reference=dtrain, categorical_feature=categorical, free_raw_data=False,
    )

    def objective(trial):
        params = {
            "objective": "binary",
            "metric": "binary_logloss",
            "learning_rate": trial.suggest_float("learning_rate", 0.02, 0.08, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 31, 127),
            "min_child_samples": trial.suggest_int(
                "min_child_samples", 100, 1000, step=100
            ),
            "feature_fraction": trial.suggest_float(
                "feature_fraction", 0.70, 1.00, step=0.05
            ),
            "max_depth": -1,
            "bagging_fraction": 0.80,
            "bagging_freq": 1,
            "lambda_l1": 0.0,
            "lambda_l2": trial.suggest_float("lambda_l2", 1e-2, 100.0, log=True),
            "feature_pre_filter": False,
            "seed": SEED,
            "num_threads": args.threads,
            "verbosity": -1,
        }
        model = lgb.train(
            params, dtrain, num_boost_round=500,
            valid_sets=[dvalid], valid_names=["validation_2022"],
            callbacks=[
                lgb.early_stopping(50, verbose=False),
                lgb.log_evaluation(0),
                pruning_callback(trial),
            ],
        )
        trial.set_user_attr("best_iteration", int(model.best_iteration))
        return float(model.best_score["validation_2022"]["binary_logloss"])

    study_suffix = "full" if args.max_rows_per_year is None else f"sample_{args.max_rows_per_year}"
    study_name = f"hmda_lightgbm_{study_suffix}"
    storage = "sqlite:///" + (OUT / "models" / "optuna_study.db").as_posix()
    summaries = optuna.study.get_all_study_summaries(storage=storage)
    matching = [s for s in summaries if s.study_name == study_name]
    selected_mode = args.study_mode
    if selected_mode == "ask" and matching:
        existing_trials = matching[0].n_trials
        print(f"\nExisting Optuna study found: {study_name} ({existing_trials} trials)")
        try:
            choice = input(
                "Choose [1] resume, [2] overwrite and restart, or [3] cancel "
                "(default: 1): "
            ).strip().lower()
        except EOFError:
            choice = "1"
        if choice in {"3", "c", "cancel"}:
            print("Run cancelled by user; existing study was not changed.")
            return
        selected_mode = "overwrite" if choice in {"2", "o", "overwrite"} else "resume"
    elif selected_mode == "ask":
        selected_mode = "resume"

    if selected_mode == "overwrite":
        # Clear only generated artifacts in this run's exact output directory.
        for generated_dir in ("figures", "tables", "source_data", "logs"):
            target = (OUT / generated_dir).resolve()
            if target.parent == OUT.resolve() and target.exists():
                shutil.rmtree(target)
            target.mkdir(parents=True, exist_ok=True)
        for generated_file in (
            "model_results.xlsx", "workbook_validation.json",
            "feature_abbreviation_table.csv", "feature_abbreviation_table.xlsx",
            "smoke_test_report.md", "run_manifest.json",
        ):
            target = OUT / generated_file
            if target.exists():
                target.unlink()
        model_file = OUT / "models" / "lightgbm_optuna_model.txt"
        if model_file.exists():
            model_file.unlink()
        # Remove all legacy/canonical studies for the same data-scale suffix.
        for old_study in summaries:
            if old_study.study_name.endswith(f"_{study_suffix}"):
                optuna.delete_study(study_name=old_study.study_name, storage=storage)
        print(f"Previous study overwritten: {study_name}")

    study = optuna.create_study(
        study_name=study_name,
        storage=storage,
        load_if_exists=(selected_mode == "resume"),
        direction="minimize",
        sampler=optuna.samplers.TPESampler(seed=SEED),
        pruner=optuna.pruners.MedianPruner(
            n_startup_trials=5, n_warmup_steps=50, interval_steps=10
        ),
    )
    completed_or_pruned = sum(
        t.state in (optuna.trial.TrialState.COMPLETE, optuna.trial.TrialState.PRUNED)
        for t in study.trials
    )
    remaining = max(0, args.trials - completed_or_pruned)
    if remaining:
        print(
            f"Study mode: {selected_mode}; existing trials: {completed_or_pruned}; "
            f"new trials to run: {remaining}."
        )
        study.optimize(objective, n_trials=remaining, n_jobs=1, gc_after_trial=True)
    else:
        print(
            f"Study already contains {completed_or_pruned} trials, meeting the "
            f"requested total of {args.trials}; no new trials will run."
        )

    best_params = dict(study.best_trial.params)
    best_iteration = int(study.best_trial.user_attrs.get("best_iteration", 200))
    print(f"Best 2022 log loss: {study.best_value:.8f}")
    print(f"Best iteration: {best_iteration}")
    print(json.dumps(best_params, ensure_ascii=False, indent=2))
    runtime_log.append({
        "stage": "optuna", "status": "OK",
        "elapsed_seconds": round(time.time() - started, 3),
        "detail": f"{len(study.trials)} trials; best log loss={study.best_value:.8f}",
    })

    # Honest tuning metrics: model trained on 2018-2021 and evaluated on 2022.
    tuning_params = {
        "objective": "binary", "metric": "binary_logloss", **best_params,
        "max_depth": -1, "bagging_fraction": 0.80, "bagging_freq": 1,
        "lambda_l1": 0.0, "feature_pre_filter": False, "seed": SEED,
        "num_threads": args.threads, "verbosity": -1,
    }
    selected_tuning_model = lgb.train(
        tuning_params, dtrain, num_boost_round=best_iteration,
        callbacks=[lgb.log_evaluation(0)],
    )
    p_tune_train = selected_tuning_model.predict(
        tune_train[features], num_iteration=best_iteration
    )
    p_tune_valid = selected_tuning_model.predict(
        tune_valid[features], num_iteration=best_iteration
    )
    y_threshold = tune_valid["y_denied"].to_numpy(copy=True)
    p_threshold = np.asarray(p_tune_valid, dtype=float).copy()
    tune_valid[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_tune_valid
    ).to_parquet(
        OUT / "source_data" / "predictions_2022_threshold_selection.parquet", index=False
    )
    del selected_tuning_model, p_tune_train, p_tune_valid

    # Release tuning matrices before creating the full refit matrices.
    del dtrain, dvalid, tune_train, tune_valid
    gc.collect()

    # Phase 2: refit 2018-2022, then evaluate untouched future years.
    final_train = df[df["x_activity_year"].between(2018, 2022)].copy()
    external_valid = df[df["x_activity_year"] == 2023].copy()
    final_test = df[df["x_activity_year"] == 2024].copy()
    del df
    gc.collect()
    align_categories(final_train, [external_valid, final_test], categorical)
    final_params = {
        "objective": "binary",
        "metric": "binary_logloss",
        **best_params,
        "max_depth": -1,
        "bagging_fraction": 0.80,
        "bagging_freq": 1,
        "lambda_l1": 0.0,
        "feature_pre_filter": False,
        "seed": SEED,
        "num_threads": args.threads,
        "verbosity": -1,
    }
    final_dataset = lgb.Dataset(
        final_train[features], label=final_train["y_denied"],
        categorical_feature=categorical, free_raw_data=False,
        params={"feature_pre_filter": False},
    )
    final_model = lgb.train(
        final_params, final_dataset, num_boost_round=best_iteration,
        callbacks=[lgb.log_evaluation(50)],
    )
    p_train = final_model.predict(
        final_train[features], num_iteration=best_iteration
    )
    p_valid = final_model.predict(
        external_valid[features], num_iteration=best_iteration
    )
    p_test = final_model.predict(
        final_test[features], num_iteration=best_iteration
    )
    final_train[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_train
    ).to_parquet(OUT / "source_data" / "predictions_train_2018_2022.parquet", index=False)
    external_valid[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_valid
    ).to_parquet(OUT / "source_data" / "predictions_validation_2023.parquet", index=False)
    final_test[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_test
    ).to_parquet(OUT / "source_data" / "predictions_test_2024.parquet", index=False)
    save_lightgbm_model(
        final_model, OUT / "models" / "lightgbm_optuna_model.txt"
    )
    runtime_log.append({
        "stage": "final_model", "status": "OK",
        "elapsed_seconds": round(time.time() - started, 3),
        "detail": "Refit on 2018-2022; predictions created for 2023 and 2024",
    })
    manifest = {
        "model": "Optuna-LightGBM",
        "optimization_target": "2022 binary_logloss",
        "decision_threshold_rule": "Maximize Youden J on 2022 only",
        "seed": SEED,
        "run_type": "smoke_test_2trials" if args.smoke_test else "formal",
        "requested_total_trials": args.trials,
        "study_mode": selected_mode,
        "best_2022_log_loss": float(study.best_value),
        "best_iteration": best_iteration,
        "best_parameters": best_params,
        "optimized_parameters": [
            "learning_rate", "num_leaves", "min_child_samples",
            "feature_fraction", "lambda_l2",
        ],
        "fixed_parameters": {
            "max_depth": -1,
            "bagging_fraction": 0.80,
            "bagging_freq": 1,
            "lambda_l1": 0.0,
        },
        "optimization_search": "five core LightGBM parameters",
        "features": features,
        "protected_attributes_in_model": False,
        "class_balancing": False,
        "tuning_train_years": "2018-2021",
        "tuning_validation_year": 2022,
        "refit_years": "2018-2022",
        "external_validation_year": 2023,
        "final_test_year": 2024,
        "sample_rows_per_year": args.max_rows_per_year,
        "software": {
            "Python": platform.python_version(), "Platform": platform.platform(),
            "LightGBM": lgb.__version__, "Optuna": optuna.__version__,
            "pandas": pd.__version__, "NumPy": np.__version__,
            "PyArrow": pyarrow.__version__,
        },
    }
    (OUT / "run_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    run_config = {
        **manifest,
        "feature_count": len(features),
        "categorical_features": categorical,
        "protected_attributes_in_model": False,
        "natural_class_distribution": True,
        "smoke_shap_sample": 2000 if args.smoke_test else "configured formal sample",
        "smoke_permutation_sample": 2000 if args.smoke_test else 30000,
        "smoke_permutation_repeats": 2 if args.smoke_test else 5,
    }
    reporting = generate_reporting_bundle(
        model=final_model, study=study, features=features, categorical=categorical,
        final_train=final_train, valid=external_valid, test=final_test,
        p_train=p_train, p_valid=p_valid, p_test=p_test,
        y_threshold=y_threshold, p_threshold=p_threshold,
        audit_path=AUDIT_DATA, out_dir=OUT, smoke=args.smoke_test,
        run_config=run_config, runtime_log=runtime_log,
    )
    reporting["study"] = study
    runtime_log.append({
        "stage": "reporting", "status": "OK",
        "elapsed_seconds": round(time.time() - started, 3),
        "detail": f"{reporting['figure_count']} figures and {len(reporting['tables'])} tables generated",
    })
    pd.DataFrame(runtime_log).to_csv(
        OUT / "tables" / "Runtime_Log.csv", index=False, encoding="utf-8-sig"
    )
    reporting["tables"]["Runtime_Log"] = pd.DataFrame(runtime_log)
    excel_ok = build_excel_workbook()
    verdict = None
    if args.smoke_test:
        verdict = write_smoke_test_report(reporting, excel_ok, time.time() - started)

    print("\nExternal validation metrics (2023):")
    print(reporting["tables"]["Metrics_Validation_2023"].to_string(index=False))
    print("\nFinal test metrics (2024):")
    print(reporting["tables"]["Metrics_Test_2024"].to_string(index=False))
    if verdict:
        print(f"\nSmoke-test verdict: {verdict}")
    print(f"\nResults saved to: {OUT}")
    print(f"Elapsed time: {time.time() - started:.1f} seconds")


if __name__ == "__main__":
    main()
