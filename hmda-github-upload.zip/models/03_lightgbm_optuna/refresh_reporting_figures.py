"""Refresh reporting-only figures from saved formal-run outputs.

This script does not retrain the model and does not read or modify the raw
modeling databases.  It only redraws figures whose numeric annotations are
required to use four decimal places.
"""

from __future__ import annotations

import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Polygon

from model_reporting import (
    BLACK,
    GREY,
    NEG_COLOR,
    POS_COLOR,
    make_m2,
    make_m3,
    make_m4,
    save_figure,
    short_feature_name,
    style_axis,
)


HERE = Path(__file__).resolve().parent
OUT = HERE / "results"


def redraw_local_explanations() -> None:
    for code in ["TN", "TP", "FP", "FN"]:
        source_path = OUT / "source_data" / f"Figure_X5_{code}.csv"
        data = pd.read_csv(source_path)
        if data.empty or "status" in data.columns:
            continue

        label = str(data["case_type"].iloc[0])
        probability = float(data["predicted_probability"].iloc[0])
        base_value = float(data["base_value_log_odds"].iloc[0])
        y_positions = np.arange(len(data))[::-1]
        starts = data["step_start_log_odds"].to_numpy(float)
        ends = data["step_end_log_odds"].to_numpy(float)
        values = data["shap_value"].to_numpy(float)
        x_span = max(1e-6, float(max(ends.max(), starts.max()) - min(ends.min(), starts.min())))

        fig, ax = plt.subplots(figsize=(17 / 2.54, 9 / 2.54))
        for ypos, value, start_value, end_value in zip(y_positions, values, starts, ends):
            half_height = 0.34
            tip = min(abs(value) * 0.18, x_span * 0.025)
            if value >= 0:
                vertices = [
                    (start_value, ypos - half_height),
                    (end_value - tip, ypos - half_height),
                    (end_value, ypos),
                    (end_value - tip, ypos + half_height),
                    (start_value, ypos + half_height),
                ]
            else:
                vertices = [
                    (start_value, ypos - half_height),
                    (end_value + tip, ypos - half_height),
                    (end_value, ypos),
                    (end_value + tip, ypos + half_height),
                    (start_value, ypos + half_height),
                ]
            ax.add_patch(
                Polygon(
                    vertices,
                    closed=True,
                    facecolor=POS_COLOR if value >= 0 else NEG_COLOR,
                    edgecolor="white",
                    linewidth=0.5,
                )
            )

        final_value = float(ends[-1])
        ax.axvline(base_value, color=GREY, ls="--", lw=0.8, label="Base")
        ax.axvline(final_value, color=BLACK, ls=":", lw=0.9, label="Final")
        labels = [
            short_feature_name(feature) if feature != "Sum of other features" else "OTHER"
            for feature in data["feature"]
        ]
        ax.set_yticks(y_positions, labels)
        ax.set_ylim(-0.6, len(data) - 0.4)
        ax.set_xlabel("Model output")
        style_axis(ax)
        legend_location = {"TN": "lower right", "TP": "upper right",
                           "FP": "upper right", "FN": "lower left"}[code]
        legend = ax.legend(
            title=f"{label}; p={probability:.4f}", fontsize=8.5,
            loc=legend_location, ncol=2, borderaxespad=0.35,
            handlelength=1.15, labelspacing=0.25, columnspacing=0.8,
            borderpad=0.35, framealpha=0.94, title_fontsize=9,
        )
        legend.get_frame().set_facecolor("white")
        fig.subplots_adjust(left=0.20, right=0.97, bottom=0.16, top=0.86)
        save_figure(fig, OUT, f"Figure_X5_{code}")


def main() -> None:
    validation = pd.read_parquet(OUT / "source_data" / "predictions_validation_2023.parquet")
    test = pd.read_parquet(OUT / "source_data" / "predictions_test_2024.parquet")
    metrics_validation = pd.read_csv(OUT / "tables" / "Metrics_Validation_2023.csv").iloc[0].to_dict()
    metrics_test = pd.read_csv(OUT / "tables" / "Metrics_Test_2024.csv").iloc[0].to_dict()
    threshold = float(metrics_test["threshold"])

    make_m2(
        validation["y_denied"].to_numpy(),
        validation["predicted_probability"].to_numpy(),
        test["y_denied"].to_numpy(),
        test["predicted_probability"].to_numpy(),
        OUT,
    )
    make_m3(
        pd.read_csv(OUT / "tables" / "Calibration_Bins.csv"),
        test["y_denied"].to_numpy(),
        test["predicted_probability"].to_numpy(),
        threshold,
        metrics_validation,
        metrics_test,
        OUT,
    )
    make_m4(
        pd.read_csv(OUT / "tables" / "Confusion_Matrix_Counts.csv"),
        pd.read_csv(OUT / "tables" / "Confusion_Matrix_Rates.csv"),
        pd.read_csv(OUT / "tables" / "Threshold_Metrics.csv"),
        threshold,
        OUT,
    )
    redraw_local_explanations()

    manifest_path = OUT / "run_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["model"] = "Optuna-LightGBM"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Refreshed Figure_M2, Figure_M3, Figure_M4, and Figure_X5_TN/TP/FP/FN")


if __name__ == "__main__":
    main()
