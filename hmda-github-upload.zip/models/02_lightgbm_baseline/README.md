# Fixed-parameter LightGBM baseline

This folder contains the ordinary LightGBM benchmark with a fixed,
pre-specified parameter set. It is separate from both the Logistic benchmark
and the Optuna-optimized LightGBM main model.

Run the formal model in the VSCode Base terminal:

```powershell
python run_lightgbm.py
```

Optional smaller test run:

```powershell
python run_lightgbm.py --max-rows-per-year 100000
```

All generated metrics, predictions, feature importance, and the fitted model
are written to this folder's `results` directory.
