"""Run the fixed-parameter HMDA LightGBM benchmark from VSCode Base.

Install once:
    python -m pip install lightgbm pandas pyarrow numpy scipy

Formal run:
    python run_lightgbm.py

Optional smaller test:
    python run_lightgbm.py --max-rows-per-year 100000
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import pandas as pd

try:
    import lightgbm as lgb
    import pyarrow.parquet as pq
except ImportError as exc:
    raise SystemExit(
        "Missing dependency. In the VSCode Base terminal run:\n"
        "python -m pip install lightgbm pandas pyarrow numpy scipy\n"
        f"Import error: {exc}"
    ) from exc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = ROOT / "data" / "data" / "modeling" / "main_homogeneous_peer.parquet"
OUT = HERE / "results"
RANDOM_SEED = 20260731


def auc(y, p):
    y = np.asarray(y, dtype=np.int8)
    p = np.asarray(p, dtype=float)
    order = np.argsort(p, kind="mergesort")
    ranks = np.arange(1, len(y) + 1, dtype=float)
    sorted_p = p[order]
    i = 0
    while i < len(sorted_p):
        j = i + 1
        while j < len(sorted_p) and sorted_p[j] == sorted_p[i]:
            j += 1
        ranks[i:j] = ranks[i:j].mean()
        i = j
    n1 = int(y.sum())
    n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return np.nan
    return float((ranks[y[order] == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def average_precision(y, p):
    y = np.asarray(y, dtype=np.int8)
    order = np.argsort(-np.asarray(p), kind="mergesort")
    sorted_y = y[order]
    positives = int(sorted_y.sum())
    if positives == 0:
        return np.nan
    cumulative = np.cumsum(sorted_y)
    ranks = np.arange(1, len(sorted_y) + 1)
    return float((cumulative[sorted_y == 1] / ranks[sorted_y == 1]).sum() / positives)


def metric_row(split, y, p):
    y = np.asarray(y, dtype=np.int8)
    p = np.clip(np.asarray(p, dtype=float), 1e-15, 1 - 1e-15)
    pred = (p >= 0.5).astype(np.int8)
    tp = int(((pred == 1) & (y == 1)).sum())
    tn = int(((pred == 0) & (y == 0)).sum())
    fp = int(((pred == 1) & (y == 0)).sum())
    fn = int(((pred == 0) & (y == 1)).sum())
    return {
        "split": split,
        "n": len(y),
        "denial_rate": float(y.mean()),
        "roc_auc": auc(y, p),
        "average_precision": average_precision(y, p),
        "log_loss": float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))),
        "brier_score": float(np.mean((p - y) ** 2)),
        "accuracy_at_0_5": float((pred == y).mean()),
        "precision_at_0_5": tp / (tp + fp) if tp + fp else np.nan,
        "recall_at_0_5": tp / (tp + fn) if tp + fn else np.nan,
        "specificity_at_0_5": tn / (tn + fp) if tn + fp else np.nan,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "tp": tp,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-rows-per-year", type=int, default=None)
    args, unknown_args = parser.parse_known_args()
    if unknown_args:
        print(f"Ignoring VSCode/Jupyter arguments: {unknown_args}")

    started = time.time()
    OUT.mkdir(parents=True, exist_ok=True)
    if not DATA.exists():
        raise FileNotFoundError(f"Data file not found: {DATA}")

    schema = pq.ParquetFile(DATA).schema.names
    features = [c for c in schema if c.startswith("x_") and c != "x_activity_year"]
    columns = ["application_row_id", "y_denied", "x_activity_year", *features]
    df = pd.read_parquet(DATA, columns=list(dict.fromkeys(columns)), engine="pyarrow")
    df["y_denied"] = pd.to_numeric(df["y_denied"], errors="raise").astype("int8")
    df["x_activity_year"] = pd.to_numeric(
        df["x_activity_year"], errors="raise"
    ).astype("int16")

    if args.max_rows_per_year:
        df = (
            df.groupby("x_activity_year", group_keys=False)
            .apply(
                lambda group: group.sample(
                    min(len(group), args.max_rows_per_year), random_state=RANDOM_SEED
                )
            )
            .reset_index(drop=True)
        )

    categorical = [
        column
        for column in [
            "x_state_code",
            "x_county_code",
            "x_msa_md",
            "x_preapproval",
            "x_loan_type",
            "x_dti_category",
        ]
        if column in df.columns
    ]
    for column in categorical:
        df[column] = (
            df[column].astype("string").fillna("__MISSING__").astype("category")
        )
    for column in features:
        if column not in categorical and not pd.api.types.is_numeric_dtype(df[column]):
            df[column] = pd.to_numeric(df[column], errors="coerce")

    train = df[df["x_activity_year"].between(2018, 2022)].copy()
    valid = df[df["x_activity_year"] == 2023].copy()
    test = df[df["x_activity_year"] == 2024].copy()
    print(f"Train 2018-2022: {len(train):,} (denial={train.y_denied.mean():.4%})")
    print(f"Validation 2023: {len(valid):,} (denial={valid.y_denied.mean():.4%})")
    print(f"Test 2024:       {len(test):,} (denial={test.y_denied.mean():.4%})")
    print("Protected attributes are excluded from model features.")

    params = {
        "objective": "binary",
        "metric": ["binary_logloss", "auc"],
        "learning_rate": 0.05,
        "num_leaves": 63,
        "min_child_samples": 100,
        "feature_fraction": 0.80,
        "bagging_fraction": 0.80,
        "bagging_freq": 1,
        "lambda_l2": 1.0,
        "seed": RANDOM_SEED,
        "num_threads": -1,
        "verbosity": -1,
    }
    dtrain = lgb.Dataset(
        train[features],
        label=train.y_denied,
        categorical_feature=categorical,
        free_raw_data=False,
    )
    dvalid = lgb.Dataset(
        valid[features],
        label=valid.y_denied,
        reference=dtrain,
        categorical_feature=categorical,
        free_raw_data=False,
    )
    model = lgb.train(
        params,
        dtrain,
        num_boost_round=500,
        valid_sets=[dvalid],
        valid_names=["validation"],
        callbacks=[lgb.early_stopping(50), lgb.log_evaluation(50)],
    )
    p_valid = model.predict(valid[features], num_iteration=model.best_iteration)
    p_test = model.predict(test[features], num_iteration=model.best_iteration)

    metrics = pd.DataFrame(
        [
            metric_row("validation_2023", valid.y_denied, p_valid),
            metric_row("test_2024", test.y_denied, p_test),
        ]
    )
    metrics.to_csv(OUT / "metrics_by_split.csv", index=False, encoding="utf-8-sig")

    importance = pd.DataFrame(
        {
            "feature": features,
            "gain": model.feature_importance("gain"),
            "split": model.feature_importance("split"),
        }
    )
    importance.sort_values("gain", ascending=False).to_csv(
        OUT / "feature_importance.csv", index=False, encoding="utf-8-sig"
    )

    valid[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_valid
    ).to_parquet(OUT / "validation_predictions_2023.parquet", index=False)
    test[["application_row_id", "x_activity_year", "y_denied"]].assign(
        predicted_probability=p_test
    ).to_parquet(OUT / "test_predictions_2024.parquet", index=False)
    # LightGBM's native Windows file writer may reject paths containing
    # non-ASCII characters. Export in memory and let Python write the file.
    model_path = OUT / "lightgbm_model.txt"
    model_path.write_text(
        model.model_to_string(num_iteration=model.best_iteration),
        encoding="utf-8",
    )
    (OUT / "run_manifest.json").write_text(
        json.dumps(
            {
                "model": "Fixed-parameter LightGBM",
                "seed": RANDOM_SEED,
                "features": features,
                "categorical_features": categorical,
                "train_years": "2018-2022",
                "validation_year": 2023,
                "test_year": 2024,
                "best_iteration": int(model.best_iteration),
                "parameters": params,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print("\nFinal metrics:")
    print(metrics.to_string(index=False))
    print(f"\nResults saved to: {OUT}")
    print(f"Elapsed time: {time.time() - started:.1f} seconds")


if __name__ == "__main__":
    main()
